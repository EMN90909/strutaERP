# Struta ERP — Funeral Home Management System

Struta is a purpose-built, multi-tenant ERP for funeral homes. It replaces generic business software with a calm, simple system designed for funeral home staff.

---

## What's Inside

| Module | Purpose |
|---|---|
| **Dashboard** | Active cases, revenue, outstanding invoices, upcoming tasks |
| **Cases** | Full funeral workflow: lead → consultation → quote → booking → service → completion |
| **Contacts** | Bereaved families, suppliers, partners |
| **Employees** | Staff records, roles, departments |
| **Sales** | Booking and quotation pipeline |
| **Invoices** | Funeral service billing with line items |
| **Payments** | Cash, bank transfer, M-Pesa, PayPal |
| **Products** | Caskets, services, packages, flowers, transport |
| **Inventory** | Stock levels by branch/location |
| **Purchases** | Supplier purchase orders |
| **Timesheets** | Staff time logging against cases |
| **Messages** | Internal staff chat by channel |
| **Blog** | Funeral home news and updates |
| **Support** | Helpdesk ticket submission |
| **Billing** | PayPal monthly subscriptions, plan management |
| **Settings** | Tenant profile, user management, roles |

---

## Tech Stack

- **Frontend**: React 18 + TypeScript + Vite + Tailwind CSS
- **Backend**: Convex (realtime database, queries, mutations, auth)
- **Auth**: Clerk (JWT, session management, multi-user)
- **Billing**: PayPal Subscriptions API
- **Hosting**: Docker + Nginx (static SPA)

---

## Local Development Setup

### Prerequisites
- Node.js 20+
- A [Convex](https://convex.dev) account (free)
- A [Clerk](https://clerk.com) account (free)
- A [PayPal Developer](https://developer.paypal.com) account

### 1. Clone and install

```bash
git clone <your-repo>
cd struta
npm install
```

### 2. Set up Convex

```bash
npx convex dev
```

This will open a browser, create a project, and give you your `VITE_CONVEX_URL`.

### 3. Set up Clerk

1. Go to [dashboard.clerk.com](https://dashboard.clerk.com)
2. Create a new application
3. Copy your **Publishable Key** → `VITE_CLERK_PUBLISHABLE_KEY`
4. In Clerk settings, add your Convex URL to the JWT templates if needed

### 4. Set up PayPal

1. Go to [developer.paypal.com](https://developer.paypal.com)
2. Create a sandbox app → copy **Client ID** → `VITE_PAYPAL_CLIENT_ID`
3. In the PayPal dashboard, create a **Product** then create 3 **Subscription Plans**:
   - Starter: KES 4,900/month
   - Professional: KES 9,900/month
   - Enterprise: KES 19,900/month
4. Copy each Plan ID into the `.env` file

### 5. Create your `.env` file

```bash
cp .env.example .env
# Edit .env and fill in all values
```

### 6. Run in development

```bash
# Terminal 1 — Convex backend
npx convex dev

# Terminal 2 — React frontend
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Docker Deployment

### Build and run

```bash
# Build the Docker image
docker build -t struta-erp .

# Run the container
docker run -d -p 80:80 --name struta struta-erp
```

### With Docker Compose

```bash
docker-compose up -d
```

The app will be available at [http://localhost](http://localhost)

### For HTTPS in production

Use **Caddy** or **Nginx Proxy Manager** in front of the container. Caddy example:

```
your-domain.com {
    reverse_proxy struta:80
}
```

### Image size
The production Docker image is approximately **25–35 MB** (nginx:alpine base + static assets only).

---

## Environment Variables

| Variable | Description |
|---|---|
| `VITE_CONVEX_URL` | Your Convex deployment URL |
| `VITE_CLERK_PUBLISHABLE_KEY` | Clerk frontend publishable key |
| `VITE_PAYPAL_CLIENT_ID` | PayPal app client ID |
| `VITE_PAYPAL_PLAN_STARTER` | PayPal Plan ID for Starter plan |
| `VITE_PAYPAL_PLAN_PROFESSIONAL` | PayPal Plan ID for Professional plan |
| `VITE_PAYPAL_PLAN_ENTERPRISE` | PayPal Plan ID for Enterprise plan |

---

## First-Time Use

1. Sign up at `/sign-up`
2. Complete onboarding to create your funeral home workspace
3. Your account starts with a **14-day free trial**
4. Go to **Billing** to activate a PayPal subscription before trial ends

---

## Multi-Tenancy

Every piece of data in Struta belongs to a tenant (funeral home). The rules are:

- Every database record carries a `tenantId`
- All Convex queries filter by `tenantId`
- All mutations verify the user belongs to the target tenant
- Users can only see and edit their own home's data
- Platform-level admin access is separate from tenant access

Tenant isolation is enforced at the database query level — not just the UI.

---

## User Roles

| Role | Access |
|---|---|
| **Owner** | Everything including billing and user management |
| **Admin** | All modules, user management, no billing |
| **Manager** | Cases, contacts, employees, reports |
| **Staff** | Cases, timesheets, contacts (limited) |
| **Finance** | Invoices, payments, financial reports |
| **Support** | View cases and contacts |
| **Readonly** | View only |

---

## PayPal Webhook Setup

For production, configure PayPal webhooks to call your backend:

1. In PayPal Developer Dashboard → Webhooks
2. Add endpoint: `https://your-domain.com/api/paypal/webhook`
3. Subscribe to events:
   - `BILLING.SUBSCRIPTION.RENEWED`
   - `BILLING.SUBSCRIPTION.PAYMENT.FAILED`
   - `BILLING.SUBSCRIPTION.CANCELLED`
4. Implement a Convex HTTP Action to handle these and call `handlePayPalWebhook`

---

## Architecture Notes

- Convex replaces all traditional backend: REST API, database, auth middleware
- Realtime updates come free from Convex's reactive query model
- The frontend is a pure static SPA — no server-side rendering needed
- Docker image runs nginx serving the static build — minimal resource usage
- Tailwind is compiled at build time — no runtime CSS overhead

---

## Remaining TODOs / Known Limitations

- [ ] PayPal webhook HTTP endpoint (Convex HTTP Action) needs wiring for production renewals
- [ ] Email notifications (e.g. invoice sent, case update) — can use Convex Actions + Resend/SendGrid
- [ ] PDF invoice export — add `react-pdf` or server-side generation
- [ ] File/document attachments on cases — add Convex file storage
- [ ] Recruitment pipeline page (UI stub only)
- [ ] Website builder module (planned — out of scope for v1)
- [ ] Custom fields UI (schema ready, UI pending)
- [ ] Audit log viewer (schema ready, UI pending)
- [ ] Mobile app — PWA manifest can be added for offline-capable mobile use
- [ ] Advanced reporting / analytics charts — stub present, can extend with recharts
