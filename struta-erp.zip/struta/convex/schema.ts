import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  // ─── TENANTS (Funeral Homes) ───────────────────────────────────────────────
  tenants: defineTable({
    name: v.string(),
    slug: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    country: v.optional(v.string()),
    logoUrl: v.optional(v.string()),
    website: v.optional(v.string()),
    status: v.union(v.literal("active"), v.literal("suspended"), v.literal("cancelled"), v.literal("trialing")),
    subscriptionStatus: v.union(
      v.literal("active"),
      v.literal("trialing"),
      v.literal("past_due"),
      v.literal("cancelled"),
      v.literal("suspended")
    ),
    plan: v.union(v.literal("starter"), v.literal("professional"), v.literal("enterprise")),
    paypalSubscriptionId: v.optional(v.string()),
    paypalCustomerId: v.optional(v.string()),
    trialEndsAt: v.optional(v.number()),
    billingCycleEnd: v.optional(v.number()),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_slug", ["slug"]),

  // ─── USERS ─────────────────────────────────────────────────────────────────
  users: defineTable({
    tenantId: v.id("tenants"),
    clerkId: v.string(),
    email: v.string(),
    name: v.string(),
    avatarUrl: v.optional(v.string()),
    role: v.union(
      v.literal("owner"),
      v.literal("admin"),
      v.literal("manager"),
      v.literal("staff"),
      v.literal("finance"),
      v.literal("support"),
      v.literal("readonly")
    ),
    isActive: v.boolean(),
    lastLoginAt: v.optional(v.number()),
    createdAt: v.number(),
  })
    .index("by_clerk", ["clerkId"])
    .index("by_tenant", ["tenantId"]),

  // ─── CONTACTS (Bereaved Families / Clients) ────────────────────────────────
  contacts: defineTable({
    tenantId: v.id("tenants"),
    type: v.union(v.literal("family"), v.literal("supplier"), v.literal("partner"), v.literal("other")),
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    country: v.optional(v.string()),
    notes: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    isArchived: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.number(),
    createdBy: v.id("users"),
  }).index("by_tenant", ["tenantId"]),

  // ─── EMPLOYEES (Staff) ─────────────────────────────────────────────────────
  employees: defineTable({
    tenantId: v.id("tenants"),
    userId: v.optional(v.id("users")),
    firstName: v.string(),
    lastName: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    role: v.string(),
    department: v.optional(v.string()),
    startDate: v.optional(v.string()),
    salary: v.optional(v.number()),
    status: v.union(v.literal("active"), v.literal("inactive"), v.literal("on_leave")),
    address: v.optional(v.string()),
    emergencyContact: v.optional(v.string()),
    notes: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_tenant", ["tenantId"]),

  // ─── PRODUCTS (Caskets, Services, Packages) ────────────────────────────────
  products: defineTable({
    tenantId: v.id("tenants"),
    name: v.string(),
    description: v.optional(v.string()),
    category: v.union(
      v.literal("casket"),
      v.literal("service"),
      v.literal("package"),
      v.literal("flowers"),
      v.literal("transport"),
      v.literal("venue"),
      v.literal("other")
    ),
    price: v.number(),
    costPrice: v.optional(v.number()),
    sku: v.optional(v.string()),
    isActive: v.boolean(),
    taxRate: v.optional(v.number()),
    unit: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_tenant", ["tenantId"]),

  // ─── INVENTORY ─────────────────────────────────────────────────────────────
  inventory: defineTable({
    tenantId: v.id("tenants"),
    productId: v.id("products"),
    location: v.string(),
    quantity: v.number(),
    minQuantity: v.optional(v.number()),
    lastRestockedAt: v.optional(v.number()),
    notes: v.optional(v.string()),
    updatedAt: v.number(),
  })
    .index("by_tenant", ["tenantId"])
    .index("by_product", ["productId"]),

  // ─── CASES / PROJECTS (Funeral Workflows) ─────────────────────────────────
  cases: defineTable({
    tenantId: v.id("tenants"),
    caseNumber: v.string(),
    deceasedName: v.string(),
    deceasedDob: v.optional(v.string()),
    deceasedDod: v.optional(v.string()),
    primaryContactId: v.optional(v.id("contacts")),
    assignedToId: v.optional(v.id("employees")),
    status: v.union(
      v.literal("lead"),
      v.literal("consultation"),
      v.literal("quoted"),
      v.literal("booked"),
      v.literal("in_progress"),
      v.literal("completed"),
      v.literal("cancelled")
    ),
    serviceDate: v.optional(v.string()),
    serviceType: v.optional(v.string()),
    serviceLocation: v.optional(v.string()),
    notes: v.optional(v.string()),
    totalValue: v.optional(v.number()),
    tags: v.optional(v.array(v.string())),
    createdAt: v.number(),
    updatedAt: v.number(),
    createdBy: v.id("users"),
  })
    .index("by_tenant", ["tenantId"])
    .index("by_status", ["tenantId", "status"]),

  // ─── CASE TASKS ────────────────────────────────────────────────────────────
  caseTasks: defineTable({
    tenantId: v.id("tenants"),
    caseId: v.id("cases"),
    title: v.string(),
    description: v.optional(v.string()),
    assignedToId: v.optional(v.id("employees")),
    dueDate: v.optional(v.string()),
    status: v.union(v.literal("pending"), v.literal("in_progress"), v.literal("done")),
    priority: v.union(v.literal("low"), v.literal("normal"), v.literal("high")),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_case", ["caseId"])
    .index("by_tenant", ["tenantId"]),

  // ─── INVOICES ──────────────────────────────────────────────────────────────
  invoices: defineTable({
    tenantId: v.id("tenants"),
    invoiceNumber: v.string(),
    caseId: v.optional(v.id("cases")),
    contactId: v.id("contacts"),
    status: v.union(
      v.literal("draft"),
      v.literal("sent"),
      v.literal("paid"),
      v.literal("partial"),
      v.literal("overdue"),
      v.literal("cancelled")
    ),
    issueDate: v.string(),
    dueDate: v.string(),
    lineItems: v.array(v.object({
      productId: v.optional(v.id("products")),
      description: v.string(),
      quantity: v.number(),
      unitPrice: v.number(),
      taxRate: v.optional(v.number()),
      total: v.number(),
    })),
    subtotal: v.number(),
    taxTotal: v.number(),
    total: v.number(),
    paidAmount: v.number(),
    currency: v.string(),
    notes: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
    createdBy: v.id("users"),
  })
    .index("by_tenant", ["tenantId"])
    .index("by_case", ["caseId"]),

  // ─── PAYMENTS ──────────────────────────────────────────────────────────────
  payments: defineTable({
    tenantId: v.id("tenants"),
    invoiceId: v.id("invoices"),
    amount: v.number(),
    currency: v.string(),
    method: v.union(
      v.literal("cash"),
      v.literal("bank_transfer"),
      v.literal("paypal"),
      v.literal("mpesa"),
      v.literal("card"),
      v.literal("cheque"),
      v.literal("other")
    ),
    reference: v.optional(v.string()),
    paypalTransactionId: v.optional(v.string()),
    mpesaCode: v.optional(v.string()),
    paidAt: v.number(),
    notes: v.optional(v.string()),
    recordedBy: v.id("users"),
    createdAt: v.number(),
  }).index("by_tenant", ["tenantId"]).index("by_invoice", ["invoiceId"]),

  // ─── PURCHASES ─────────────────────────────────────────────────────────────
  purchases: defineTable({
    tenantId: v.id("tenants"),
    purchaseNumber: v.string(),
    supplierId: v.id("contacts"),
    status: v.union(v.literal("draft"), v.literal("ordered"), v.literal("received"), v.literal("cancelled")),
    orderDate: v.string(),
    expectedDate: v.optional(v.string()),
    lineItems: v.array(v.object({
      productId: v.optional(v.id("products")),
      description: v.string(),
      quantity: v.number(),
      unitCost: v.number(),
      total: v.number(),
    })),
    total: v.number(),
    notes: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.number(),
    createdBy: v.id("users"),
  }).index("by_tenant", ["tenantId"]),

  // ─── TIMESHEETS ────────────────────────────────────────────────────────────
  timesheets: defineTable({
    tenantId: v.id("tenants"),
    employeeId: v.id("employees"),
    caseId: v.optional(v.id("cases")),
    date: v.string(),
    startTime: v.string(),
    endTime: v.optional(v.string()),
    hours: v.optional(v.number()),
    description: v.optional(v.string()),
    status: v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected")),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index("by_tenant", ["tenantId"])
    .index("by_employee", ["employeeId"]),

  // ─── MESSAGES (Internal Chat) ──────────────────────────────────────────────
  messages: defineTable({
    tenantId: v.id("tenants"),
    senderId: v.id("users"),
    recipientId: v.optional(v.id("users")),
    channelId: v.optional(v.string()),
    content: v.string(),
    isRead: v.boolean(),
    caseId: v.optional(v.id("cases")),
    createdAt: v.number(),
  })
    .index("by_tenant", ["tenantId"])
    .index("by_channel", ["tenantId", "channelId"]),

  // ─── SUPPORT TICKETS ───────────────────────────────────────────────────────
  supportTickets: defineTable({
    tenantId: v.id("tenants"),
    submittedBy: v.id("users"),
    subject: v.string(),
    description: v.string(),
    priority: v.union(v.literal("low"), v.literal("normal"), v.literal("high"), v.literal("urgent")),
    status: v.union(v.literal("open"), v.literal("in_progress"), v.literal("resolved"), v.literal("closed")),
    createdAt: v.number(),
    updatedAt: v.number(),
    resolvedAt: v.optional(v.number()),
  }).index("by_tenant", ["tenantId"]),

  // ─── BILLING RECORDS ───────────────────────────────────────────────────────
  billingRecords: defineTable({
    tenantId: v.id("tenants"),
    type: v.union(
      v.literal("subscription_activated"),
      v.literal("subscription_renewed"),
      v.literal("payment_failed"),
      v.literal("subscription_cancelled"),
      v.literal("plan_changed"),
      v.literal("trial_started"),
      v.literal("trial_ended")
    ),
    amount: v.optional(v.number()),
    currency: v.optional(v.string()),
    paypalEventId: v.optional(v.string()),
    paypalSubscriptionId: v.optional(v.string()),
    description: v.string(),
    occurredAt: v.number(),
    createdAt: v.number(),
  }).index("by_tenant", ["tenantId"]),

  // ─── BLOG POSTS ────────────────────────────────────────────────────────────
  blogPosts: defineTable({
    tenantId: v.id("tenants"),
    title: v.string(),
    slug: v.string(),
    content: v.string(),
    excerpt: v.optional(v.string()),
    authorId: v.id("users"),
    status: v.union(v.literal("draft"), v.literal("published")),
    publishedAt: v.optional(v.number()),
    coverImageUrl: v.optional(v.string()),
    tags: v.optional(v.array(v.string())),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index("by_tenant", ["tenantId"]),

  // ─── CUSTOM FIELDS ─────────────────────────────────────────────────────────
  customFields: defineTable({
    tenantId: v.id("tenants"),
    entity: v.string(),
    label: v.string(),
    key: v.string(),
    type: v.union(v.literal("text"), v.literal("number"), v.literal("date"), v.literal("boolean"), v.literal("select")),
    options: v.optional(v.array(v.string())),
    isRequired: v.boolean(),
    createdAt: v.number(),
  }).index("by_tenant", ["tenantId"]),

  // ─── AUDIT LOG ─────────────────────────────────────────────────────────────
  auditLog: defineTable({
    tenantId: v.id("tenants"),
    userId: v.id("users"),
    action: v.string(),
    entity: v.string(),
    entityId: v.optional(v.string()),
    details: v.optional(v.string()),
    createdAt: v.number(),
  }).index("by_tenant", ["tenantId"]),
});
