import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { requireUser, requireTenantAccess, requireRole } from "./auth";

// ─── TENANT QUERIES ────────────────────────────────────────────────────────

export const getMyTenant = query({
  args: {},
  handler: async (ctx) => {
    const user = await requireUser(ctx);
    const tenant = await ctx.db.get(user.tenantId);
    return tenant;
  },
});

export const getMe = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    const user = await ctx.db
      .query("users")
      .withIndex("by_clerk", (q) => q.eq("clerkId", identity.subject))
      .first();
    return user;
  },
});

// ─── DASHBOARD ANALYTICS ───────────────────────────────────────────────────

export const getDashboardStats = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);

    const cases = await ctx.db.query("cases").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    const invoices = await ctx.db.query("invoices").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    const employees = await ctx.db.query("employees").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();

    const activeCases = cases.filter(c => c.status === "in_progress" || c.status === "booked").length;
    const completedCases = cases.filter(c => c.status === "completed").length;
    const totalRevenue = invoices.filter(i => i.status === "paid").reduce((s, i) => s + i.total, 0);
    const outstanding = invoices.filter(i => i.status === "sent" || i.status === "overdue").reduce((s, i) => s + (i.total - i.paidAmount), 0);
    const overdueInvoices = invoices.filter(i => i.status === "overdue").length;

    const recentCases = cases
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 5);

    return {
      activeCases,
      completedCases,
      totalCases: cases.length,
      totalRevenue,
      outstanding,
      overdueInvoices,
      activeStaff: employees.filter(e => e.status === "active").length,
      recentCases,
    };
  },
});

// ─── USERS MANAGEMENT ──────────────────────────────────────────────────────

export const getTenantUsers = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);
    return ctx.db.query("users").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
  },
});

export const createTenant = mutation({
  args: {
    name: v.string(),
    slug: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    clerkId: v.string(),
    userName: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const tenantId = await ctx.db.insert("tenants", {
      name: args.name,
      slug: args.slug,
      email: args.email,
      phone: args.phone,
      status: "active",
      subscriptionStatus: "trialing",
      plan: "starter",
      trialEndsAt: now + 14 * 24 * 60 * 60 * 1000,
      createdAt: now,
      updatedAt: now,
    });

    const userId = await ctx.db.insert("users", {
      tenantId,
      clerkId: args.clerkId,
      email: args.email,
      name: args.userName,
      role: "owner",
      isActive: true,
      createdAt: now,
    });

    await ctx.db.insert("billingRecords", {
      tenantId,
      type: "trial_started",
      description: "14-day free trial started",
      occurredAt: now,
      createdAt: now,
    });

    return { tenantId, userId };
  },
});

export const updateTenantSettings = mutation({
  args: {
    tenantId: v.id("tenants"),
    name: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    country: v.optional(v.string()),
    website: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...updates }) => {
    await requireRole(ctx, tenantId, ["owner", "admin"]);
    await ctx.db.patch(tenantId, { ...updates, updatedAt: Date.now() });
  },
});

export const inviteUser = mutation({
  args: {
    tenantId: v.id("tenants"),
    email: v.string(),
    name: v.string(),
    role: v.union(
      v.literal("admin"), v.literal("manager"), v.literal("staff"),
      v.literal("finance"), v.literal("support"), v.literal("readonly")
    ),
    clerkId: v.string(),
  },
  handler: async (ctx, { tenantId, email, name, role, clerkId }) => {
    await requireRole(ctx, tenantId, ["owner", "admin"]);
    const userId = await ctx.db.insert("users", {
      tenantId, clerkId, email, name, role,
      isActive: true, createdAt: Date.now(),
    });
    return userId;
  },
});
