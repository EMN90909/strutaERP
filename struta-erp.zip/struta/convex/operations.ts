import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { requireTenantAccess, requireRole } from "./auth";

// ─── BILLING ───────────────────────────────────────────────────────────────

export const getBillingRecords = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireRole(ctx, tenantId, ["owner", "admin", "finance"]);
    return ctx.db.query("billingRecords")
      .withIndex("by_tenant", q => q.eq("tenantId", tenantId))
      .order("desc")
      .collect();
  },
});

export const activatePayPalSubscription = mutation({
  args: {
    tenantId: v.id("tenants"),
    paypalSubscriptionId: v.string(),
    plan: v.union(v.literal("starter"), v.literal("professional"), v.literal("enterprise")),
  },
  handler: async (ctx, { tenantId, paypalSubscriptionId, plan }) => {
    await requireRole(ctx, tenantId, ["owner", "admin"]);
    const now = Date.now();
    await ctx.db.patch(tenantId, {
      paypalSubscriptionId,
      plan,
      subscriptionStatus: "active",
      status: "active",
      billingCycleEnd: now + 30 * 24 * 60 * 60 * 1000,
      updatedAt: now,
    });
    await ctx.db.insert("billingRecords", {
      tenantId,
      type: "subscription_activated",
      paypalSubscriptionId,
      description: `${plan} plan activated via PayPal`,
      occurredAt: now,
      createdAt: now,
    });
  },
});

export const handlePayPalWebhook = mutation({
  args: {
    tenantId: v.id("tenants"),
    eventType: v.string(),
    paypalEventId: v.string(),
    paypalSubscriptionId: v.string(),
    amount: v.optional(v.number()),
    currency: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const { tenantId, eventType, paypalEventId, paypalSubscriptionId, amount, currency } = args;

    if (eventType === "BILLING.SUBSCRIPTION.RENEWED") {
      await ctx.db.patch(tenantId, {
        subscriptionStatus: "active",
        billingCycleEnd: now + 30 * 24 * 60 * 60 * 1000,
        updatedAt: now,
      });
      await ctx.db.insert("billingRecords", {
        tenantId, paypalEventId, paypalSubscriptionId,
        type: "subscription_renewed",
        amount, currency,
        description: "Monthly subscription renewed",
        occurredAt: now, createdAt: now,
      });
    } else if (eventType === "BILLING.SUBSCRIPTION.PAYMENT.FAILED") {
      await ctx.db.patch(tenantId, { subscriptionStatus: "past_due", updatedAt: now });
      await ctx.db.insert("billingRecords", {
        tenantId, paypalEventId, paypalSubscriptionId,
        type: "payment_failed",
        amount, currency,
        description: "Monthly payment failed",
        occurredAt: now, createdAt: now,
      });
    } else if (eventType === "BILLING.SUBSCRIPTION.CANCELLED") {
      await ctx.db.patch(tenantId, { subscriptionStatus: "cancelled", status: "cancelled", updatedAt: now });
      await ctx.db.insert("billingRecords", {
        tenantId, paypalEventId, paypalSubscriptionId,
        type: "subscription_cancelled",
        description: "Subscription cancelled",
        occurredAt: now, createdAt: now,
      });
    }
  },
});

// ─── MESSAGES (Staff Chat) ─────────────────────────────────────────────────

export const listMessages = query({
  args: { tenantId: v.id("tenants"), channelId: v.optional(v.string()), limit: v.optional(v.number()) },
  handler: async (ctx, { tenantId, channelId, limit }) => {
    await requireTenantAccess(ctx, tenantId);
    const channel = channelId ?? "general";
    const msgs = await ctx.db.query("messages")
      .withIndex("by_channel", q => q.eq("tenantId", tenantId).eq("channelId", channel))
      .order("desc")
      .take(limit ?? 50);
    const withSenders = await Promise.all(msgs.map(async m => ({
      ...m,
      sender: await ctx.db.get(m.senderId),
    })));
    return withSenders.reverse();
  },
});

export const sendMessage = mutation({
  args: {
    tenantId: v.id("tenants"),
    content: v.string(),
    channelId: v.optional(v.string()),
    caseId: v.optional(v.id("cases")),
  },
  handler: async (ctx, { tenantId, content, channelId, caseId }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    return ctx.db.insert("messages", {
      tenantId,
      senderId: user._id,
      content,
      channelId: channelId ?? "general",
      caseId,
      isRead: false,
      createdAt: Date.now(),
    });
  },
});

// ─── TIMESHEETS ────────────────────────────────────────────────────────────

export const listTimesheets = query({
  args: { tenantId: v.id("tenants"), employeeId: v.optional(v.id("employees")) },
  handler: async (ctx, { tenantId, employeeId }) => {
    await requireTenantAccess(ctx, tenantId);
    const all = await ctx.db.query("timesheets")
      .withIndex("by_tenant", q => q.eq("tenantId", tenantId))
      .collect();
    return employeeId ? all.filter(t => t.employeeId === employeeId) : all;
  },
});

export const logTime = mutation({
  args: {
    tenantId: v.id("tenants"),
    employeeId: v.id("employees"),
    caseId: v.optional(v.id("cases")),
    date: v.string(),
    startTime: v.string(),
    endTime: v.optional(v.string()),
    hours: v.optional(v.number()),
    description: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    return ctx.db.insert("timesheets", {
      tenantId, ...data, status: "pending",
      createdAt: now, updatedAt: now,
    });
  },
});

// ─── SUPPORT TICKETS ───────────────────────────────────────────────────────

export const listSupportTickets = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);
    return ctx.db.query("supportTickets")
      .withIndex("by_tenant", q => q.eq("tenantId", tenantId))
      .order("desc")
      .collect();
  },
});

export const createSupportTicket = mutation({
  args: {
    tenantId: v.id("tenants"),
    subject: v.string(),
    description: v.string(),
    priority: v.union(v.literal("low"), v.literal("normal"), v.literal("high"), v.literal("urgent")),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    return ctx.db.insert("supportTickets", {
      tenantId, ...data,
      submittedBy: user._id,
      status: "open",
      createdAt: now, updatedAt: now,
    });
  },
});

// ─── PURCHASES ─────────────────────────────────────────────────────────────

export const listPurchases = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);
    return ctx.db.query("purchases")
      .withIndex("by_tenant", q => q.eq("tenantId", tenantId))
      .order("desc")
      .collect();
  },
});

export const createPurchase = mutation({
  args: {
    tenantId: v.id("tenants"),
    supplierId: v.id("contacts"),
    orderDate: v.string(),
    expectedDate: v.optional(v.string()),
    lineItems: v.array(v.object({
      productId: v.optional(v.id("products")),
      description: v.string(),
      quantity: v.number(),
      unitCost: v.number(),
      total: v.number(),
    })),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    const count = await ctx.db.query("purchases").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    const purchaseNumber = `PO-${String(count.length + 1).padStart(4, "0")}`;
    const total = data.lineItems.reduce((s, i) => s + i.total, 0);
    return ctx.db.insert("purchases", {
      tenantId, ...data, purchaseNumber, total,
      status: "draft",
      createdAt: now, updatedAt: now, createdBy: user._id,
    });
  },
});

// ─── BLOG POSTS ────────────────────────────────────────────────────────────

export const listBlogPosts = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);
    return ctx.db.query("blogPosts")
      .withIndex("by_tenant", q => q.eq("tenantId", tenantId))
      .collect();
  },
});

export const createBlogPost = mutation({
  args: {
    tenantId: v.id("tenants"),
    title: v.string(),
    slug: v.string(),
    content: v.string(),
    excerpt: v.optional(v.string()),
    status: v.union(v.literal("draft"), v.literal("published")),
    tags: v.optional(v.array(v.string())),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    return ctx.db.insert("blogPosts", {
      tenantId, ...data,
      authorId: user._id,
      publishedAt: data.status === "published" ? now : undefined,
      createdAt: now, updatedAt: now,
    });
  },
});
