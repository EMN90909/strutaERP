import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { requireTenantAccess, requireUser } from "./auth";

export const listCases = query({
  args: {
    tenantId: v.id("tenants"),
    status: v.optional(v.string()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, { tenantId, status, limit }) => {
    await requireTenantAccess(ctx, tenantId);
    let q = ctx.db.query("cases").withIndex("by_tenant", q => q.eq("tenantId", tenantId));
    const all = await q.collect();
    const filtered = status ? all.filter(c => c.status === status) : all;
    const sorted = filtered.sort((a, b) => b.createdAt - a.createdAt);
    return limit ? sorted.slice(0, limit) : sorted;
  },
});

export const getCase = query({
  args: { tenantId: v.id("tenants"), caseId: v.id("cases") },
  handler: async (ctx, { tenantId, caseId }) => {
    await requireTenantAccess(ctx, tenantId);
    const c = await ctx.db.get(caseId);
    if (!c || c.tenantId !== tenantId) throw new Error("Case not found");
    return c;
  },
});

export const getCaseTasks = query({
  args: { tenantId: v.id("tenants"), caseId: v.id("cases") },
  handler: async (ctx, { tenantId, caseId }) => {
    await requireTenantAccess(ctx, tenantId);
    return ctx.db.query("caseTasks").withIndex("by_case", q => q.eq("caseId", caseId)).collect();
  },
});

export const createCase = mutation({
  args: {
    tenantId: v.id("tenants"),
    deceasedName: v.string(),
    deceasedDob: v.optional(v.string()),
    deceasedDod: v.optional(v.string()),
    primaryContactId: v.optional(v.id("contacts")),
    serviceDate: v.optional(v.string()),
    serviceType: v.optional(v.string()),
    serviceLocation: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    const count = await ctx.db.query("cases").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    const caseNumber = `CASE-${String(count.length + 1).padStart(4, "0")}`;
    
    return ctx.db.insert("cases", {
      tenantId, ...data, caseNumber,
      status: "lead",
      createdAt: now,
      updatedAt: now,
      createdBy: user._id,
    });
  },
});

export const updateCase = mutation({
  args: {
    tenantId: v.id("tenants"),
    caseId: v.id("cases"),
    status: v.optional(v.union(
      v.literal("lead"), v.literal("consultation"), v.literal("quoted"),
      v.literal("booked"), v.literal("in_progress"), v.literal("completed"), v.literal("cancelled")
    )),
    deceasedName: v.optional(v.string()),
    serviceDate: v.optional(v.string()),
    serviceType: v.optional(v.string()),
    serviceLocation: v.optional(v.string()),
    notes: v.optional(v.string()),
    assignedToId: v.optional(v.id("employees")),
    totalValue: v.optional(v.number()),
  },
  handler: async (ctx, { tenantId, caseId, ...updates }) => {
    await requireTenantAccess(ctx, tenantId);
    const existing = await ctx.db.get(caseId);
    if (!existing || existing.tenantId !== tenantId) throw new Error("Not found");
    await ctx.db.patch(caseId, { ...updates, updatedAt: Date.now() });
  },
});

export const addCaseTask = mutation({
  args: {
    tenantId: v.id("tenants"),
    caseId: v.id("cases"),
    title: v.string(),
    description: v.optional(v.string()),
    assignedToId: v.optional(v.id("employees")),
    dueDate: v.optional(v.string()),
    priority: v.union(v.literal("low"), v.literal("normal"), v.literal("high")),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    return ctx.db.insert("caseTasks", {
      tenantId, ...data,
      status: "pending",
      createdAt: now,
      updatedAt: now,
    });
  },
});

export const updateCaseTask = mutation({
  args: {
    tenantId: v.id("tenants"),
    taskId: v.id("caseTasks"),
    status: v.optional(v.union(v.literal("pending"), v.literal("in_progress"), v.literal("done"))),
    title: v.optional(v.string()),
    dueDate: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, taskId, ...updates }) => {
    await requireTenantAccess(ctx, tenantId);
    const task = await ctx.db.get(taskId);
    if (!task || task.tenantId !== tenantId) throw new Error("Not found");
    await ctx.db.patch(taskId, { ...updates, updatedAt: Date.now() });
  },
});
