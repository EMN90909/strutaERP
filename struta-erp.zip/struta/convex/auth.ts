import { QueryCtx, MutationCtx } from "./_generated/server";
import { Id } from "./_generated/dataModel";

export async function getAuthenticatedUser(ctx: QueryCtx | MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) return null;
  
  const user = await ctx.db
    .query("users")
    .withIndex("by_clerk", (q) => q.eq("clerkId", identity.subject))
    .first();
  
  return user;
}

export async function requireUser(ctx: QueryCtx | MutationCtx) {
  const user = await getAuthenticatedUser(ctx);
  if (!user) throw new Error("Authentication required");
  if (!user.isActive) throw new Error("Account is inactive");
  return user;
}

export async function requireTenantAccess(
  ctx: QueryCtx | MutationCtx,
  tenantId: Id<"tenants">
) {
  const user = await requireUser(ctx);
  if (user.tenantId !== tenantId) {
    throw new Error("Access denied: wrong tenant");
  }
  return user;
}

export async function requireRole(
  ctx: QueryCtx | MutationCtx,
  tenantId: Id<"tenants">,
  roles: string[]
) {
  const user = await requireTenantAccess(ctx, tenantId);
  if (!roles.includes(user.role)) {
    throw new Error(`Access denied: requires role ${roles.join(" or ")}`);
  }
  return user;
}

export async function requireTenantActive(ctx: QueryCtx | MutationCtx, tenantId: Id<"tenants">) {
  const tenant = await ctx.db.get(tenantId);
  if (!tenant) throw new Error("Tenant not found");
  if (tenant.subscriptionStatus === "cancelled" || tenant.subscriptionStatus === "suspended") {
    throw new Error("Subscription inactive. Please renew your plan.");
  }
  return tenant;
}
