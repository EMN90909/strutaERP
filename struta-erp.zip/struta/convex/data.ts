import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { requireTenantAccess } from "./auth";

// ─── CONTACTS ──────────────────────────────────────────────────────────────

export const listContacts = query({
  args: { tenantId: v.id("tenants"), type: v.optional(v.string()) },
  handler: async (ctx, { tenantId, type }) => {
    await requireTenantAccess(ctx, tenantId);
    const all = await ctx.db.query("contacts").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    return type ? all.filter(c => c.type === type && !c.isArchived) : all.filter(c => !c.isArchived);
  },
});

export const createContact = mutation({
  args: {
    tenantId: v.id("tenants"),
    type: v.union(v.literal("family"), v.literal("supplier"), v.literal("partner"), v.literal("other")),
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    city: v.optional(v.string()),
    country: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    return ctx.db.insert("contacts", {
      tenantId, ...data, isArchived: false,
      createdAt: now, updatedAt: now, createdBy: user._id,
    });
  },
});

export const updateContact = mutation({
  args: {
    tenantId: v.id("tenants"),
    contactId: v.id("contacts"),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    address: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, contactId, ...updates }) => {
    await requireTenantAccess(ctx, tenantId);
    const c = await ctx.db.get(contactId);
    if (!c || c.tenantId !== tenantId) throw new Error("Not found");
    await ctx.db.patch(contactId, { ...updates, updatedAt: Date.now() });
  },
});

// ─── EMPLOYEES ─────────────────────────────────────────────────────────────

export const listEmployees = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);
    return ctx.db.query("employees").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
  },
});

export const createEmployee = mutation({
  args: {
    tenantId: v.id("tenants"),
    firstName: v.string(),
    lastName: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    role: v.string(),
    department: v.optional(v.string()),
    startDate: v.optional(v.string()),
    salary: v.optional(v.number()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    return ctx.db.insert("employees", {
      tenantId, ...data, status: "active",
      createdAt: now, updatedAt: now,
    });
  },
});

// ─── PRODUCTS ──────────────────────────────────────────────────────────────

export const listProducts = query({
  args: { tenantId: v.id("tenants"), category: v.optional(v.string()) },
  handler: async (ctx, { tenantId, category }) => {
    await requireTenantAccess(ctx, tenantId);
    const all = await ctx.db.query("products").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    return category ? all.filter(p => p.category === category && p.isActive) : all.filter(p => p.isActive);
  },
});

export const createProduct = mutation({
  args: {
    tenantId: v.id("tenants"),
    name: v.string(),
    description: v.optional(v.string()),
    category: v.union(
      v.literal("casket"), v.literal("service"), v.literal("package"),
      v.literal("flowers"), v.literal("transport"), v.literal("venue"), v.literal("other")
    ),
    price: v.number(),
    costPrice: v.optional(v.number()),
    sku: v.optional(v.string()),
    taxRate: v.optional(v.number()),
    unit: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    return ctx.db.insert("products", { tenantId, ...data, isActive: true, createdAt: now, updatedAt: now });
  },
});

// ─── INVENTORY ─────────────────────────────────────────────────────────────

export const listInventory = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);
    const items = await ctx.db.query("inventory").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    return Promise.all(items.map(async item => ({
      ...item,
      product: await ctx.db.get(item.productId),
    })));
  },
});

export const updateInventory = mutation({
  args: {
    tenantId: v.id("tenants"),
    productId: v.id("products"),
    location: v.string(),
    quantity: v.number(),
    minQuantity: v.optional(v.number()),
  },
  handler: async (ctx, { tenantId, productId, location, quantity, minQuantity }) => {
    await requireTenantAccess(ctx, tenantId);
    const existing = await ctx.db.query("inventory")
      .withIndex("by_product", q => q.eq("productId", productId))
      .first();
    const now = Date.now();
    if (existing) {
      await ctx.db.patch(existing._id, { quantity, minQuantity, location, updatedAt: now });
    } else {
      await ctx.db.insert("inventory", { tenantId, productId, location, quantity, minQuantity, updatedAt: now });
    }
  },
});

// ─── INVOICES ──────────────────────────────────────────────────────────────

export const listInvoices = query({
  args: { tenantId: v.id("tenants"), status: v.optional(v.string()) },
  handler: async (ctx, { tenantId, status }) => {
    await requireTenantAccess(ctx, tenantId);
    const all = await ctx.db.query("invoices").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    return status ? all.filter(i => i.status === status) : all;
  },
});

export const createInvoice = mutation({
  args: {
    tenantId: v.id("tenants"),
    contactId: v.id("contacts"),
    caseId: v.optional(v.id("cases")),
    issueDate: v.string(),
    dueDate: v.string(),
    currency: v.string(),
    lineItems: v.array(v.object({
      productId: v.optional(v.id("products")),
      description: v.string(),
      quantity: v.number(),
      unitPrice: v.number(),
      taxRate: v.optional(v.number()),
      total: v.number(),
    })),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    const now = Date.now();
    const count = await ctx.db.query("invoices").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
    const invoiceNumber = `INV-${String(count.length + 1).padStart(4, "0")}`;
    const subtotal = data.lineItems.reduce((s, i) => s + i.total, 0);
    const taxTotal = data.lineItems.reduce((s, i) => s + (i.total * (i.taxRate ?? 0) / 100), 0);
    const total = subtotal + taxTotal;
    
    return ctx.db.insert("invoices", {
      tenantId, ...data, invoiceNumber, subtotal, taxTotal, total,
      paidAmount: 0, status: "draft",
      createdAt: now, updatedAt: now, createdBy: user._id,
    });
  },
});

export const updateInvoiceStatus = mutation({
  args: {
    tenantId: v.id("tenants"),
    invoiceId: v.id("invoices"),
    status: v.union(v.literal("draft"), v.literal("sent"), v.literal("paid"), v.literal("partial"), v.literal("overdue"), v.literal("cancelled")),
  },
  handler: async (ctx, { tenantId, invoiceId, status }) => {
    await requireTenantAccess(ctx, tenantId);
    const inv = await ctx.db.get(invoiceId);
    if (!inv || inv.tenantId !== tenantId) throw new Error("Not found");
    await ctx.db.patch(invoiceId, { status, updatedAt: Date.now() });
  },
});

// ─── PAYMENTS ──────────────────────────────────────────────────────────────

export const recordPayment = mutation({
  args: {
    tenantId: v.id("tenants"),
    invoiceId: v.id("invoices"),
    amount: v.number(),
    currency: v.string(),
    method: v.union(v.literal("cash"), v.literal("bank_transfer"), v.literal("paypal"), v.literal("mpesa"), v.literal("card"), v.literal("cheque"), v.literal("other")),
    reference: v.optional(v.string()),
    mpesaCode: v.optional(v.string()),
    paypalTransactionId: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, { tenantId, ...data }) => {
    const user = await requireTenantAccess(ctx, tenantId);
    const inv = await ctx.db.get(data.invoiceId);
    if (!inv || inv.tenantId !== tenantId) throw new Error("Not found");
    const now = Date.now();
    
    await ctx.db.insert("payments", { tenantId, ...data, paidAt: now, recordedBy: user._id, createdAt: now });
    
    const newPaid = inv.paidAmount + data.amount;
    const newStatus = newPaid >= inv.total ? "paid" : "partial";
    await ctx.db.patch(data.invoiceId, { paidAmount: newPaid, status: newStatus, updatedAt: now });
  },
});

export const listPayments = query({
  args: { tenantId: v.id("tenants") },
  handler: async (ctx, { tenantId }) => {
    await requireTenantAccess(ctx, tenantId);
    return ctx.db.query("payments").withIndex("by_tenant", q => q.eq("tenantId", tenantId)).collect();
  },
});
