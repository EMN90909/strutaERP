import { createContext, useContext, ReactNode } from 'react'
import { useQuery } from 'convex/react'
import { api } from '../../convex/_generated/api'
import { Id } from '../../convex/_generated/dataModel'
import LoadingScreen from '../components/ui/LoadingScreen'

interface TenantContextType {
  tenant: any
  user: any
  tenantId: Id<'tenants'>
  role: string
  canDo: (action: string) => boolean
  hasRole: (roles: string[]) => boolean
  isSubscribed: boolean
}

const TenantContext = createContext<TenantContextType | null>(null)

const ROLE_PERMISSIONS: Record<string, string[]> = {
  owner:    ['*'],
  admin:    ['read', 'write', 'delete', 'manage_users'],
  manager:  ['read', 'write', 'delete'],
  staff:    ['read', 'write'],
  finance:  ['read', 'write_finance'],
  support:  ['read', 'write_support'],
  readonly: ['read'],
}

export function TenantProvider({ children }: { children: ReactNode }) {
  const user   = useQuery(api.tenants.getMe)
  const tenant = useQuery(api.tenants.getMyTenant)

  if (user === undefined || tenant === undefined) return <LoadingScreen />
  if (!user || !tenant) {
    window.location.href = '/onboarding'
    return null
  }

  const canDo = (action: string) => {
    const perms = ROLE_PERMISSIONS[user.role] ?? []
    return perms.includes('*') || perms.includes(action)
  }

  const hasRole = (roles: string[]) => roles.includes(user.role)

  const isSubscribed = ['active', 'trialing'].includes(tenant.subscriptionStatus)

  return (
    <TenantContext.Provider value={{ tenant, user, tenantId: tenant._id, role: user.role, canDo, hasRole, isSubscribed }}>
      {children}
    </TenantContext.Provider>
  )
}

export function useTenant() {
  const ctx = useContext(TenantContext)
  if (!ctx) throw new Error('useTenant must be used within TenantProvider')
  return ctx
}
