import { ReactNode, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { UserButton } from '@clerk/clerk-react'
import {
  LayoutDashboard, Users, Briefcase, FileText, Package,
  ShoppingCart, CreditCard, Clock, MessageSquare, BookOpen,
  LifeBuoy, Settings, ChevronLeft, ChevronRight, Building2,
  Archive, TrendingUp, UserCheck, AlertCircle, Menu, X,
} from 'lucide-react'
import { TenantProvider, useTenant } from '../../contexts/TenantContext'
import clsx from 'clsx'

const NAV = [
  { section: 'Overview' },
  { label: 'Dashboard',   href: '/dashboard',   icon: LayoutDashboard },
  { label: 'Cases',       href: '/cases',        icon: Briefcase },
  { label: 'Messages',    href: '/messages',     icon: MessageSquare },

  { section: 'Operations' },
  { label: 'Contacts',    href: '/contacts',     icon: Users },
  { label: 'Employees',   href: '/employees',    icon: UserCheck },
  { label: 'Sales',       href: '/sales',        icon: TrendingUp },
  { label: 'Timesheets',  href: '/timesheets',   icon: Clock },

  { section: 'Finance' },
  { label: 'Invoices',    href: '/invoices',     icon: FileText },
  { label: 'Payments',    href: '/payments',     icon: CreditCard },
  { label: 'Purchases',   href: '/purchases',    icon: ShoppingCart },

  { section: 'Stock' },
  { label: 'Products',    href: '/products',     icon: Package },
  { label: 'Inventory',   href: '/inventory',    icon: Archive },

  { section: 'Content' },
  { label: 'Blog',        href: '/blog',         icon: BookOpen },

  { section: 'Account' },
  { label: 'Support',     href: '/support',      icon: LifeBuoy },
  { label: 'Billing',     href: '/billing',      icon: AlertCircle },
  { label: 'Settings',    href: '/settings',     icon: Settings },
]

function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const location = useLocation()
  const { tenant } = useTenant()

  return (
    <aside className={clsx('sidebar transition-all duration-200', collapsed ? 'w-16' : 'w-60')}>
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-struta-800">
        <div className="w-8 h-8 rounded-lg bg-struta-500 flex items-center justify-center flex-shrink-0">
          <Building2 size={16} className="text-white" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <div className="text-white font-sans font-semibold text-sm leading-tight">Struta</div>
            <div className="text-struta-400 text-xs truncate">{tenant.name}</div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2">
        {NAV.map((item, i) => {
          if ('section' in item) {
            if (collapsed) return null
            return (
              <div key={i} className="px-3 pt-4 pb-1 text-xs font-semibold text-struta-500 uppercase tracking-widest">
                {item.section}
              </div>
            )
          }
          const Icon = item.icon
          const active = location.pathname === item.href || location.pathname.startsWith(item.href + '/')
          return (
            <Link
              key={item.href}
              to={item.href}
              className={clsx('nav-item mb-0.5', active && 'active', collapsed && 'justify-center px-2')}
              title={collapsed ? item.label : undefined}
            >
              <Icon size={16} className="flex-shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          )
        })}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={onToggle}
        className="flex items-center justify-center w-full py-3 border-t border-struta-800 text-struta-400 hover:text-white hover:bg-struta-800 transition-colors"
      >
        {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
      </button>
    </aside>
  )
}

function TopBar() {
  const { user } = useTenant()
  return (
    <header className="h-14 bg-white border-b border-struta-200 flex items-center justify-between px-6 flex-shrink-0">
      <div className="text-sm text-struta-500">
        Welcome, <span className="font-medium text-struta-800">{user.name}</span>
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xs px-2 py-1 rounded-full bg-struta-100 text-struta-600 capitalize">{user.role}</span>
        <UserButton afterSignOutUrl="/sign-in" />
      </div>
    </header>
  )
}

function ShellContent({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="flex h-screen overflow-hidden bg-struta-50">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Desktop sidebar */}
      <div className="hidden md:flex">
        <Sidebar collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      </div>

      {/* Mobile sidebar */}
      <div className={clsx('fixed inset-y-0 left-0 z-50 md:hidden transition-transform duration-200', mobileOpen ? 'translate-x-0' : '-translate-x-full')}>
        <Sidebar collapsed={false} onToggle={() => setMobileOpen(false)} />
      </div>

      {/* Main */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <div className="flex items-center md:hidden h-14 bg-white border-b border-struta-200 px-4 gap-3">
          <button onClick={() => setMobileOpen(true)} className="text-struta-600">
            <Menu size={20} />
          </button>
          <span className="font-sans font-semibold text-struta-800">Struta</span>
        </div>
        <TopBar />
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  )
}

export default function AppShell({ children }: { children: ReactNode }) {
  return (
    <TenantProvider>
      <ShellContent>{children}</ShellContent>
    </TenantProvider>
  )
}
