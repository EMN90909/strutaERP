import { ReactNode, useState } from 'react'
import { X, Loader2, AlertCircle, CheckCircle } from 'lucide-react'
import clsx from 'clsx'

// ─── LOADING SCREEN ────────────────────────────────────────────────────────
export default function LoadingScreen() {
  return (
    <div className="min-h-screen bg-struta-50 flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-struta-600 flex items-center justify-center">
          <Loader2 size={24} className="text-white animate-spin" />
        </div>
        <p className="text-struta-600 text-sm">Loading Struta…</p>
      </div>
    </div>
  )
}

// ─── MODAL ─────────────────────────────────────────────────────────────────
interface ModalProps {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  footer?: ReactNode
  size?: 'sm' | 'md' | 'lg'
}

export function Modal({ open, onClose, title, children, footer, size = 'md' }: ModalProps) {
  if (!open) return null
  const sizeClass = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl' }[size]
  return (
    <div className="modal-overlay fade-in" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={clsx('modal w-full', sizeClass)}>
        <div className="modal-header">
          <h3 className="text-base font-sans font-semibold text-struta-900">{title}</h3>
          <button onClick={onClose} className="text-struta-400 hover:text-struta-700 transition-colors">
            <X size={18} />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  )
}

// ─── STATUS BADGE ──────────────────────────────────────────────────────────
const STATUS_MAP: Record<string, string> = {
  active: 'badge-green', trialing: 'badge-blue', past_due: 'badge-yellow',
  cancelled: 'badge-red', suspended: 'badge-red', draft: 'badge-gray',
  sent: 'badge-blue', paid: 'badge-green', partial: 'badge-yellow',
  overdue: 'badge-red', lead: 'badge-gray', consultation: 'badge-blue',
  quoted: 'badge-yellow', booked: 'badge-purple', in_progress: 'badge-yellow',
  completed: 'badge-green', open: 'badge-blue', in_progress2: 'badge-yellow',
  resolved: 'badge-green', closed: 'badge-gray', pending: 'badge-gray',
  approved: 'badge-green', rejected: 'badge-red', ordered: 'badge-blue',
  received: 'badge-green', published: 'badge-green', inactive: 'badge-gray',
  on_leave: 'badge-yellow',
}

export function StatusBadge({ status }: { status: string }) {
  const cls = STATUS_MAP[status] ?? 'badge-gray'
  return <span className={cls}>{status.replace(/_/g, ' ')}</span>
}

// ─── EMPTY STATE ───────────────────────────────────────────────────────────
export function EmptyState({ icon: Icon, title, description, action }: {
  icon: any; title: string; description?: string; action?: ReactNode
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-4">
      <div className="w-14 h-14 rounded-2xl bg-struta-100 flex items-center justify-center mb-4">
        <Icon size={24} className="text-struta-400" />
      </div>
      <h3 className="text-base font-sans font-semibold text-struta-800 mb-1">{title}</h3>
      {description && <p className="text-sm text-struta-500 max-w-xs mb-4">{description}</p>}
      {action}
    </div>
  )
}

// ─── CONFIRM DIALOG ────────────────────────────────────────────────────────
export function ConfirmDialog({ open, onClose, onConfirm, title, message, danger }: {
  open: boolean; onClose: () => void; onConfirm: () => void;
  title: string; message: string; danger?: boolean
}) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm"
      footer={
        <>
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className={danger ? 'btn-danger' : 'btn-primary'} onClick={onConfirm}>Confirm</button>
        </>
      }
    >
      <p className="text-sm text-struta-700">{message}</p>
    </Modal>
  )
}

// ─── STAT CARD ─────────────────────────────────────────────────────────────
export function StatCard({ label, value, sub, color }: {
  label: string; value: string | number; sub?: string; color?: string
}) {
  return (
    <div className="stat-card">
      <p className="text-xs font-medium text-struta-500 uppercase tracking-wide">{label}</p>
      <p className={clsx('text-2xl font-sans font-bold mt-1', color ?? 'text-struta-900')}>{value}</p>
      {sub && <p className="text-xs text-struta-400 mt-0.5">{sub}</p>}
    </div>
  )
}

// ─── SEARCH INPUT ──────────────────────────────────────────────────────────
export function SearchInput({ value, onChange, placeholder = 'Search…' }: {
  value: string; onChange: (v: string) => void; placeholder?: string
}) {
  return (
    <div className="relative">
      <input
        className="input pl-9 w-64"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
      />
      <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-struta-400" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
      </svg>
    </div>
  )
}

// ─── ALERT ─────────────────────────────────────────────────────────────────
export function Alert({ type, message }: { type: 'error' | 'success'; message: string }) {
  const isError = type === 'error'
  return (
    <div className={clsx('flex items-start gap-3 p-3 rounded-lg text-sm', isError ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700')}>
      {isError ? <AlertCircle size={16} className="mt-0.5 flex-shrink-0" /> : <CheckCircle size={16} className="mt-0.5 flex-shrink-0" />}
      <span>{message}</span>
    </div>
  )
}

// ─── PAGE SHELL ────────────────────────────────────────────────────────────
export function PageShell({ title, actions, children }: {
  title: string; actions?: ReactNode; children: ReactNode
}) {
  return (
    <div className="flex flex-col h-full">
      <div className="page-header">
        <h1 className="page-title">{title}</h1>
        {actions && <div className="flex items-center gap-2">{actions}</div>}
      </div>
      <div className="flex-1 p-6 overflow-y-auto">{children}</div>
    </div>
  )
}
