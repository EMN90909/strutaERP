import { Routes, Route, Navigate } from 'react-router-dom'
import { useConvexAuth } from 'convex/react'
import { SignIn, SignUp } from '@clerk/clerk-react'
import AppShell from './components/layout/AppShell'
import Dashboard from './pages/dashboard/Dashboard'
import CasesPage from './pages/projects/CasesPage'
import CaseDetail from './pages/projects/CaseDetail'
import ContactsPage from './pages/contacts/ContactsPage'
import EmployeesPage from './pages/employees/EmployeesPage'
import InvoicesPage from './pages/invoices/InvoicesPage'
import InventoryPage from './pages/inventory/InventoryPage'
import ProductsPage from './pages/products/ProductsPage'
import PaymentsPage from './pages/payments/PaymentsPage'
import SalesPage from './pages/sales/SalesPage'
import PurchasesPage from './pages/purchases/PurchasesPage'
import TimesheetsPage from './pages/timesheets/TimesheetsPage'
import MessagesPage from './pages/messages/MessagesPage'
import BlogPage from './pages/blog/BlogPage'
import SupportPage from './pages/support/SupportPage'
import BillingPage from './pages/billing/BillingPage'
import SettingsPage from './pages/settings/SettingsPage'
import OnboardingPage from './pages/auth/OnboardingPage'
import LoadingScreen from './components/ui/LoadingScreen'

function AuthedApp() {
  return (
    <AppShell>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/cases" element={<CasesPage />} />
        <Route path="/cases/:id" element={<CaseDetail />} />
        <Route path="/contacts" element={<ContactsPage />} />
        <Route path="/employees" element={<EmployeesPage />} />
        <Route path="/invoices" element={<InvoicesPage />} />
        <Route path="/inventory" element={<InventoryPage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/payments" element={<PaymentsPage />} />
        <Route path="/sales" element={<SalesPage />} />
        <Route path="/purchases" element={<PurchasesPage />} />
        <Route path="/timesheets" element={<TimesheetsPage />} />
        <Route path="/messages" element={<MessagesPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/support" element={<SupportPage />} />
        <Route path="/billing" element={<BillingPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AppShell>
  )
}

function AuthPage({ component: Component, path }: { component: any; path: string }) {
  return (
    <div className="min-h-screen bg-struta-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-struta-700 flex items-center justify-center mx-auto mb-3">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
          </div>
          <h1 className="text-2xl font-sans font-semibold text-struta-900">Struta</h1>
          <p className="text-struta-500 text-sm mt-1">Funeral Home Management</p>
        </div>
        <Component routing="path" path={path} afterSignInUrl="/dashboard" afterSignUpUrl="/onboarding" />
      </div>
    </div>
  )
}

export default function App() {
  const { isLoading, isAuthenticated } = useConvexAuth()

  if (isLoading) return <LoadingScreen />

  return (
    <Routes>
      <Route path="/sign-in/*" element={<AuthPage component={SignIn} path="/sign-in" />} />
      <Route path="/sign-up/*" element={<AuthPage component={SignUp} path="/sign-up" />} />
      <Route
        path="/onboarding"
        element={isAuthenticated ? <OnboardingPage /> : <Navigate to="/sign-in" replace />}
      />
      <Route
        path="/*"
        element={isAuthenticated ? <AuthedApp /> : <Navigate to="/sign-in" replace />}
      />
    </Routes>
  )
}
