import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, StatusBadge } from '../../components/ui/LoadingScreen'
import { CreditCard, CheckCircle, AlertTriangle, Calendar, Package } from 'lucide-react'
import { format } from 'date-fns'

const PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: 4900,
    currency: 'KES',
    period: 'month',
    description: 'For small independent funeral homes',
    paypalPlanId: import.meta.env.VITE_PAYPAL_PLAN_STARTER ?? '',
    features: ['Up to 5 staff accounts', '50 cases/month', 'Invoicing & payments', 'Basic reports', 'Email support'],
  },
  {
    id: 'professional',
    name: 'Professional',
    price: 9900,
    currency: 'KES',
    period: 'month',
    description: 'For growing funeral home businesses',
    paypalPlanId: import.meta.env.VITE_PAYPAL_PLAN_PROFESSIONAL ?? '',
    features: ['Up to 20 staff accounts', 'Unlimited cases', 'Full ERP modules', 'Inventory & purchasing', 'Staff timesheets', 'Blog & website', 'Priority support'],
    recommended: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 19900,
    currency: 'KES',
    period: 'month',
    description: 'For funeral home groups & chains',
    paypalPlanId: import.meta.env.VITE_PAYPAL_PLAN_ENTERPRISE ?? '',
    features: ['Unlimited staff', 'Multi-branch support', 'Custom reporting', 'API access', 'Dedicated account manager', '24/7 support'],
  },
]

function PlanCard({ plan, current, onSelect }: { plan: typeof PLANS[0]; current: boolean; onSelect: () => void }) {
  const fmt = (n: number) => new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 }).format(n)

  return (
    <div className={`card p-6 flex flex-col relative ${plan.recommended ? 'border-struta-500 ring-2 ring-struta-300' : ''}`}>
      {plan.recommended && (
        <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-struta-700 text-white text-xs px-3 py-1 rounded-full font-medium">Most Popular</span>
      )}
      <div className="mb-4">
        <h3 className="font-sans font-semibold text-struta-900 text-lg">{plan.name}</h3>
        <p className="text-sm text-struta-500 mt-0.5">{plan.description}</p>
      </div>
      <div className="mb-5">
        <span className="text-3xl font-sans font-bold text-struta-900">{fmt(plan.price)}</span>
        <span className="text-struta-400 text-sm">/{plan.period}</span>
      </div>
      <ul className="space-y-2 mb-6 flex-1">
        {plan.features.map(f => (
          <li key={f} className="flex items-start gap-2 text-sm text-struta-600">
            <CheckCircle size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
            {f}
          </li>
        ))}
      </ul>
      {current ? (
        <div className="flex items-center justify-center gap-2 py-2 rounded-md bg-struta-100 text-struta-700 text-sm font-medium">
          <CheckCircle size={14} /> Current Plan
        </div>
      ) : (
        <button className={plan.recommended ? 'btn-primary' : 'btn-secondary'} onClick={onSelect}>
          Select {plan.name}
        </button>
      )}
    </div>
  )
}

export default function BillingPage() {
  const { tenantId, tenant } = useTenant()
  const billingRecords = useQuery(api.operations.getBillingRecords, { tenantId })
  const activateSubscription = useMutation(api.operations.activatePayPalSubscription)

  const [selectedPlan, setSelectedPlan] = useState<typeof PLANS[0] | null>(null)
  const [success, setSuccess] = useState(false)

  const handleApprove = async (data: any) => {
    if (!selectedPlan) return
    await activateSubscription({
      tenantId,
      paypalSubscriptionId: data.subscriptionID,
      plan: selectedPlan.id as any,
    })
    setSuccess(true)
    setSelectedPlan(null)
  }

  const statusColor: Record<string, string> = {
    active: 'badge-green', trialing: 'badge-blue', past_due: 'badge-yellow',
    cancelled: 'badge-red', suspended: 'badge-red',
  }
  const subStatus = tenant?.subscriptionStatus ?? 'trialing'
  const isTrial = subStatus === 'trialing'
  const trialDays = tenant?.trialEndsAt ? Math.max(0, Math.ceil((tenant.trialEndsAt - Date.now()) / 86400000)) : 0
  const fmt = (n: number) => new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 }).format(n)

  return (
    <PageShell title="Billing & Subscription">
      {success && (
        <div className="mb-6 card p-5 flex items-start gap-4 border-green-200 bg-green-50">
          <CheckCircle size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-green-800">Subscription activated!</p>
            <p className="text-sm text-green-600 mt-0.5">Your plan is now active. Thank you for choosing Struta.</p>
          </div>
        </div>
      )}

      {/* Current Status */}
      <div className="card p-6 mb-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="font-sans font-semibold text-struta-900 text-lg mb-1">Current Subscription</h2>
            <div className="flex items-center gap-3">
              <StatusBadge status={subStatus} />
              <span className="text-struta-600 text-sm capitalize">{tenant?.plan ?? 'starter'} plan</span>
            </div>
            {isTrial && (
              <div className="mt-3 flex items-start gap-2 text-sm text-amber-700 bg-amber-50 rounded-lg px-3 py-2">
                <AlertTriangle size={15} className="mt-0.5 flex-shrink-0" />
                <span>Free trial — <strong>{trialDays} days</strong> remaining. Subscribe below to continue after your trial.</span>
              </div>
            )}
            {subStatus === 'past_due' && (
              <div className="mt-3 flex items-start gap-2 text-sm text-red-700 bg-red-50 rounded-lg px-3 py-2">
                <AlertTriangle size={15} className="mt-0.5 flex-shrink-0" />
                <span>Your last payment failed. Please update your billing to avoid service interruption.</span>
              </div>
            )}
          </div>
          {tenant?.billingCycleEnd && (
            <div className="text-right text-sm">
              <div className="flex items-center gap-1 text-struta-400 justify-end"><Calendar size={13} />Next renewal</div>
              <div className="font-medium text-struta-700 mt-0.5">{format(new Date(tenant.billingCycleEnd), 'dd MMM yyyy')}</div>
            </div>
          )}
        </div>
      </div>

      {/* Plan selector */}
      {!selectedPlan && (
        <>
          <h2 className="font-sans font-semibold text-struta-800 mb-4">Choose Your Plan</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {PLANS.map(plan => (
              <PlanCard
                key={plan.id}
                plan={plan}
                current={tenant?.plan === plan.id && subStatus === 'active'}
                onSelect={() => setSelectedPlan(plan)}
              />
            ))}
          </div>
        </>
      )}

      {/* PayPal checkout */}
      {selectedPlan && (
        <div className="card p-6 mb-8">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-sans font-semibold text-struta-900">Subscribe to {selectedPlan.name}</h3>
              <p className="text-sm text-struta-500 mt-0.5">{fmt(selectedPlan.price)}/month via PayPal</p>
            </div>
            <button className="btn-ghost text-sm" onClick={() => setSelectedPlan(null)}>← Change plan</button>
          </div>
          <div className="max-w-sm">
            <PayPalScriptProvider options={{
              clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID ?? 'test',
              vault: true,
              intent: 'subscription',
            }}>
              <PayPalButtons
                style={{ layout: 'vertical', shape: 'rect', color: 'gold' }}
                createSubscription={(_data, actions) => {
                  return actions.subscription.create({ plan_id: selectedPlan.paypalPlanId || 'P-PLACEHOLDER' })
                }}
                onApprove={handleApprove}
                onError={(err) => console.error('PayPal error', err)}
              />
            </PayPalScriptProvider>
          </div>
          <p className="text-xs text-struta-400 mt-4">You'll be billed monthly. Cancel anytime from your PayPal account or by contacting support.</p>
        </div>
      )}

      {/* Billing History */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-struta-100">
          <h2 className="font-sans font-semibold text-struta-800">Billing History</h2>
        </div>
        {!billingRecords || billingRecords.length === 0 ? (
          <div className="px-5 py-10 text-center text-struta-400 text-sm">No billing records yet.</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="table-header">
              <tr>
                {['Date', 'Event', 'Amount', 'Reference'].map(h => (
                  <th key={h} className="px-5 py-3 text-left text-xs font-semibold text-struta-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(billingRecords ?? []).map(r => (
                <tr key={r._id} className="table-row">
                  <td className="px-5 py-3 text-struta-500">{format(new Date(r.occurredAt), 'dd MMM yyyy')}</td>
                  <td className="px-5 py-3 text-struta-800">{r.description}</td>
                  <td className="px-5 py-3">{r.amount != null ? fmt(r.amount) : '—'}</td>
                  <td className="px-5 py-3 text-struta-400 font-mono text-xs">{r.paypalSubscriptionId?.slice(-12) ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </PageShell>
  )
}
