import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, StatusBadge } from '../../components/ui/LoadingScreen'
import { LifeBuoy, Plus } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

const PRIORITIES = ['low', 'normal', 'high', 'urgent'] as const

export default function SupportPage() {
  const { tenantId } = useTenant()
  const tickets = useQuery(api.operations.listSupportTickets, { tenantId })
  const createTicket = useMutation(api.operations.createSupportTicket)

  const [showNew, setShowNew] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ subject: '', description: '', priority: 'normal' as const })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSave = async () => {
    if (!form.subject.trim() || !form.description.trim()) return
    setSaving(true)
    try {
      await createTicket({ tenantId, ...form })
      setShowNew(false)
      setForm({ subject: '', description: '', priority: 'normal' })
    } finally {
      setSaving(false)
    }
  }

  const PRIORITY_COLOR: Record<string, string> = { low: 'badge-gray', normal: 'badge-blue', high: 'badge-yellow', urgent: 'badge-red' }

  return (
    <PageShell
      title="Support"
      actions={<button className="btn-primary flex items-center gap-2" onClick={() => setShowNew(true)}><Plus size={16} />New Ticket</button>}
    >
      {/* Help section */}
      <div className="card p-6 mb-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-struta-100 flex items-center justify-center flex-shrink-0">
            <LifeBuoy size={20} className="text-struta-600" />
          </div>
          <div>
            <h3 className="font-sans font-semibold text-struta-800 mb-1">Need help with Struta?</h3>
            <p className="text-sm text-struta-500 mb-3">Submit a support ticket and our team will get back to you as soon as possible. For urgent operational issues, call us directly.</p>
            <div className="flex gap-3 flex-wrap">
              <a href="mailto:support@struta.app" className="btn-secondary text-xs px-3 py-1.5">Email Support</a>
              <a href="https://docs.struta.app" target="_blank" rel="noopener noreferrer" className="btn-ghost text-xs px-3 py-1.5">Documentation</a>
            </div>
          </div>
        </div>
      </div>

      {/* Tickets */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-struta-100">
          <h2 className="font-sans font-semibold text-struta-800">My Tickets</h2>
        </div>
        {!tickets || tickets.length === 0 ? (
          <EmptyState icon={LifeBuoy} title="No tickets" description="No support requests submitted yet." action={<button className="btn-primary" onClick={() => setShowNew(true)}>Submit Ticket</button>} />
        ) : (
          <table className="w-full text-sm">
            <thead className="table-header">
              <tr>
                {['Subject', 'Priority', 'Status', 'Submitted'].map(h => (
                  <th key={h} className="px-5 py-3 text-left text-xs font-semibold text-struta-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(tickets ?? []).map(t => (
                <tr key={t._id} className="table-row">
                  <td className="px-5 py-3 font-medium text-struta-800">{t.subject}</td>
                  <td className="px-5 py-3"><span className={PRIORITY_COLOR[t.priority] ?? 'badge-gray'}>{t.priority}</span></td>
                  <td className="px-5 py-3"><StatusBadge status={t.status} /></td>
                  <td className="px-5 py-3 text-struta-500">{formatDistanceToNow(new Date(t.createdAt), { addSuffix: true })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Submit Support Ticket"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleSave} disabled={saving}>{saving ? 'Submitting…' : 'Submit Ticket'}</button></>}
      >
        <div className="space-y-4">
          <div className="form-group">
            <label className="label">Subject <span className="text-red-500">*</span></label>
            <input className="input" value={form.subject} onChange={set('subject')} placeholder="Brief summary of your issue" autoFocus />
          </div>
          <div className="form-group">
            <label className="label">Priority</label>
            <select className="select" value={form.priority} onChange={set('priority')}>
              {PRIORITIES.map(p => <option key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="label">Description <span className="text-red-500">*</span></label>
            <textarea className="input resize-none" rows={5} value={form.description} onChange={set('description')} placeholder="Please describe the issue in detail. Include any steps to reproduce it." />
          </div>
        </div>
      </Modal>
    </PageShell>
  )
}
