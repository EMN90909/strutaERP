import { useQuery } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { StatCard, StatusBadge, PageShell } from '../../components/ui/LoadingScreen'
import { Briefcase, DollarSign, AlertTriangle, Users, TrendingUp, Calendar } from 'lucide-react'
import { Link } from 'react-router-dom'
import { formatDistanceToNow } from 'date-fns'

function currency(n: number) {
  return new Intl.NumberFormat('en-KE', { style: 'currency', currency: 'KES', maximumFractionDigits: 0 }).format(n)
}

export default function Dashboard() {
  const { tenantId, tenant } = useTenant()
  const stats = useQuery(api.tenants.getDashboardStats, { tenantId })

  const isTrial = tenant.subscriptionStatus === 'trialing'
  const trialDays = tenant.trialEndsAt
    ? Math.max(0, Math.ceil((tenant.trialEndsAt - Date.now()) / 86400000))
    : 0

  return (
    <PageShell title="Dashboard">
      {/* Trial Banner */}
      {isTrial && (
        <div className="mb-5 flex items-center gap-3 p-4 rounded-xl bg-yellow-50 border border-yellow-200">
          <AlertTriangle size={16} className="text-yellow-600 flex-shrink-0" />
          <p className="text-sm text-yellow-800">
            You are on a free trial — <strong>{trialDays} day{trialDays !== 1 ? 's' : ''}</strong> remaining.{' '}
            <Link to="/billing" className="underline font-medium">Activate your subscription →</Link>
          </p>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          label="Active Cases"
          value={stats?.activeCases ?? '—'}
          sub="In progress or booked"
          color="text-struta-700"
        />
        <StatCard
          label="Total Revenue"
          value={stats ? currency(stats.totalRevenue) : '—'}
          sub="From paid invoices"
          color="text-green-700"
        />
        <StatCard
          label="Outstanding"
          value={stats ? currency(stats.outstanding) : '—'}
          sub={stats?.overdueInvoices ? `${stats.overdueInvoices} overdue` : 'Unpaid invoices'}
          color={stats?.overdueInvoices ? 'text-red-700' : 'text-struta-700'}
        />
        <StatCard
          label="Active Staff"
          value={stats?.activeStaff ?? '—'}
          sub="Currently employed"
          color="text-struta-700"
        />
      </div>

      {/* Recent Cases */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-sans font-semibold text-struta-900">Recent Cases</h2>
            <Link to="/cases" className="text-xs text-struta-600 hover:text-struta-800 underline">View all</Link>
          </div>
          {!stats?.recentCases?.length ? (
            <p className="text-sm text-struta-400 text-center py-8">No cases yet. <Link to="/cases" className="text-struta-600 underline">Create your first case →</Link></p>
          ) : (
            <div className="divide-y divide-struta-100">
              {stats.recentCases.map((c: any) => (
                <Link
                  key={c._id}
                  to={`/cases/${c._id}`}
                  className="flex items-center justify-between py-3 hover:bg-struta-50 -mx-1 px-1 rounded transition-colors"
                >
                  <div>
                    <p className="text-sm font-medium text-struta-900">{c.deceasedName}</p>
                    <p className="text-xs text-struta-500">{c.caseNumber} · {formatDistanceToNow(c.createdAt, { addSuffix: true })}</p>
                  </div>
                  <StatusBadge status={c.status} />
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Quick Links */}
        <div className="card">
          <h2 className="text-base font-sans font-semibold text-struta-900 mb-4">Quick Actions</h2>
          <div className="flex flex-col gap-2">
            {[
              { label: 'New Case', href: '/cases', icon: Briefcase },
              { label: 'Create Invoice', href: '/invoices', icon: DollarSign },
              { label: 'Add Contact', href: '/contacts', icon: Users },
              { label: 'View Timesheets', href: '/timesheets', icon: Calendar },
              { label: 'Sales Pipeline', href: '/sales', icon: TrendingUp },
            ].map(({ label, href, icon: Icon }) => (
              <Link
                key={href}
                to={href}
                className="flex items-center gap-3 p-3 rounded-lg border border-struta-200 hover:border-struta-400 hover:bg-struta-50 transition-all text-sm text-struta-700 font-medium"
              >
                <Icon size={15} className="text-struta-500" />
                {label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </PageShell>
  )
}
