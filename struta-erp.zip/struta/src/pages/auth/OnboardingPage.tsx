import { useState } from 'react'
import { useMutation } from 'convex/react'
import { useUser } from '@clerk/clerk-react'
import { useNavigate } from 'react-router-dom'
import { api } from '../../../convex/_generated/api'
import { Building2, Loader2, CheckCircle } from 'lucide-react'

export default function OnboardingPage() {
  const { user } = useUser()
  const navigate = useNavigate()
  const createTenant = useMutation(api.tenants.createTenant)

  const [step, setStep] = useState(1)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    name: '',
    slug: '',
    email: user?.primaryEmailAddress?.emailAddress ?? '',
    phone: '',
  })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value
    setForm(f => ({
      ...f,
      [k]: val,
      ...(k === 'name' ? { slug: val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') } : {}),
    }))
  }

  const handleSubmit = async () => {
    if (!form.name.trim() || !form.slug.trim()) {
      setError('Funeral home name is required.')
      return
    }
    if (!user?.id) return
    setSaving(true)
    setError('')
    try {
      await createTenant({
        name: form.name.trim(),
        slug: form.slug.trim(),
        email: form.email,
        phone: form.phone || undefined,
        clerkId: user.id,
        userName: user.fullName ?? form.email,
      })
      setStep(3)
      setTimeout(() => navigate('/dashboard'), 2000)
    } catch (err: any) {
      setError(err.message ?? 'Something went wrong. Please try again.')
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen bg-struta-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-struta-700 flex items-center justify-center mx-auto mb-4">
            <Building2 size={24} className="text-white" />
          </div>
          <h1 className="text-2xl font-sans font-semibold text-struta-900">Welcome to Struta</h1>
          <p className="text-struta-500 text-sm mt-1">Let's set up your funeral home workspace</p>
        </div>

        {step === 3 ? (
          <div className="card p-8 text-center">
            <CheckCircle size={40} className="text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-sans font-semibold text-struta-900 mb-2">You're all set!</h2>
            <p className="text-struta-500 text-sm">Taking you to your dashboard…</p>
          </div>
        ) : (
          <div className="card p-6">
            <h2 className="text-lg font-sans font-semibold text-struta-800 mb-5">Your Funeral Home Details</h2>

            <div className="form-group">
              <label className="label">Funeral Home Name <span className="text-red-500">*</span></label>
              <input
                className="input"
                value={form.name}
                onChange={set('name')}
                placeholder="e.g. Sunrise Memorial Home"
                autoFocus
              />
            </div>

            <div className="form-group">
              <label className="label">Workspace ID</label>
              <input
                className="input font-mono text-sm"
                value={form.slug}
                onChange={set('slug')}
                placeholder="sunrise-memorial"
              />
              <p className="text-xs text-struta-400 mt-1">Used as your unique workspace identifier. Lowercase letters, numbers and hyphens only.</p>
            </div>

            <div className="form-group">
              <label className="label">Contact Email</label>
              <input
                className="input"
                type="email"
                value={form.email}
                onChange={set('email')}
                placeholder="admin@yourfuneralhome.com"
              />
            </div>

            <div className="form-group">
              <label className="label">Phone Number</label>
              <input
                className="input"
                type="tel"
                value={form.phone}
                onChange={set('phone')}
                placeholder="+254 700 000 000"
              />
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-lg bg-red-50 text-red-700 text-sm">{error}</div>
            )}

            <div className="bg-struta-50 rounded-lg p-4 mb-5 text-sm text-struta-600">
              <strong className="text-struta-800">14-day free trial</strong> — No credit card required to get started. You'll be asked to set up billing before your trial ends.
            </div>

            <button
              className="btn-primary w-full flex items-center justify-center gap-2"
              onClick={handleSubmit}
              disabled={saving}
            >
              {saving ? <Loader2 size={16} className="animate-spin" /> : null}
              {saving ? 'Creating workspace…' : 'Create My Workspace'}
            </button>
          </div>
        )}

        <p className="text-center text-xs text-struta-400 mt-6">
          By continuing, you agree to Struta's Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  )
}
