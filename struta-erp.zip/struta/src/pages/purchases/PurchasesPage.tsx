import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, StatusBadge } from '../../components/ui/LoadingScreen'
import { ShoppingCart, Plus, Trash2 } from 'lucide-react'
import { format } from 'date-fns'

export default function PurchasesPage() {
  const { tenantId } = useTenant()
  const purchases = useQuery(api.billing.listPurchases, { tenantId })
  const contacts = useQuery(api.data.listContacts, { tenantId, type: 'supplier' })
  const createPurchase = useMutation(api.billing.createPurchase)

  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ supplierId: '', orderDate: new Date().toISOString().split('T')[0], expectedDate: '', notes: '' })
  const [lines, setLines] = useState([{ description: '', quantity: 1, unitCost: 0, total: 0 }])
  const [saving, setSaving] = useState(false)

  function updateLine(idx: number, field: string, val: any) {
    setLines(items => items.map((item, i) => {
      if (i !== idx) return item
      const updated = { ...item, [field]: val }
      updated.total = updated.quantity * updated.unitCost
      return updated
    }))
  }

  async function handleCreate() {
    if (!form.supplierId) return
    setSaving(true)
    try {
      await createPurchase({ tenantId, supplierId: form.supplierId as any, orderDate: form.orderDate, expectedDate: form.expectedDate || undefined, lineItems: lines.filter(l => l.description), notes: form.notes || undefined })
      setShowNew(false)
      setForm({ supplierId: '', orderDate: new Date().toISOString().split('T')[0], expectedDate: '', notes: '' })
      setLines([{ description: '', quantity: 1, unitCost: 0, total: 0 }])
    } finally { setSaving(false) }
  }

  return (
    <PageShell title="Purchases" actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> New Purchase Order</button>}>
      {!purchases ? <p className="text-sm text-struta-400">Loading…</p>
        : purchases.length === 0 ? (
          <EmptyState icon={ShoppingCart} title="No purchase orders" description="Track orders from suppliers." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> New PO</button>} />
        ) : (
          <div className="table-wrapper">
            <table className="table">
              <thead><tr><th>PO #</th><th>Supplier</th><th>Order Date</th><th>Expected</th><th>Total (KES)</th><th>Status</th></tr></thead>
              <tbody>
                {purchases.map(p => (
                  <tr key={p._id}>
                    <td className="font-mono text-xs text-struta-700">{p.purchaseNumber}</td>
                    <td>{p.supplierId}</td>
                    <td>{format(new Date(p.orderDate), 'd MMM yyyy')}</td>
                    <td>{p.expectedDate ? format(new Date(p.expectedDate), 'd MMM yyyy') : '—'}</td>
                    <td className="font-medium">{p.total.toLocaleString()}</td>
                    <td><StatusBadge status={p.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="New Purchase Order" size="lg"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleCreate} disabled={saving || !form.supplierId}>{saving ? 'Creating…' : 'Create PO'}</button></>}>
        <div className="form-group">
          <label className="label">Supplier *</label>
          <select className="select" value={form.supplierId} onChange={e => setForm(f => ({ ...f, supplierId: e.target.value }))}>
            <option value="">Select supplier…</option>
            {(contacts ?? []).map(c => <option key={c._id} value={c._id}>{c.firstName} {c.lastName}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">Order Date</label><input type="date" className="input" value={form.orderDate} onChange={e => setForm(f => ({ ...f, orderDate: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Expected Delivery</label><input type="date" className="input" value={form.expectedDate} onChange={e => setForm(f => ({ ...f, expectedDate: e.target.value }))} /></div>
        </div>
        <div className="mb-4">
          <label className="label mb-2">Items</label>
          <div className="border border-struta-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-struta-50"><tr><th className="px-3 py-2 text-left">Item</th><th className="px-3 py-2 text-right w-16">Qty</th><th className="px-3 py-2 text-right w-28">Unit Cost</th><th className="px-3 py-2 text-right w-24">Total</th><th className="w-8"></th></tr></thead>
              <tbody>
                {lines.map((l, idx) => (
                  <tr key={idx} className="border-t border-struta-100">
                    <td className="px-2 py-1"><input className="input text-xs py-1" value={l.description} onChange={e => updateLine(idx, 'description', e.target.value)} /></td>
                    <td className="px-2 py-1"><input type="number" className="input text-xs py-1 text-right" value={l.quantity} onChange={e => updateLine(idx, 'quantity', Number(e.target.value))} /></td>
                    <td className="px-2 py-1"><input type="number" className="input text-xs py-1 text-right" value={l.unitCost} onChange={e => updateLine(idx, 'unitCost', Number(e.target.value))} /></td>
                    <td className="px-3 py-2 text-right">{l.total.toLocaleString()}</td>
                    <td className="px-2"><button onClick={() => setLines(i => i.filter((_, j) => j !== idx))}><Trash2 size={13} className="text-struta-300 hover:text-red-500" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button className="w-full text-xs text-struta-500 py-2 border-t border-struta-100 hover:bg-struta-50" onClick={() => setLines(i => [...i, { description: '', quantity: 1, unitCost: 0, total: 0 }])}>+ Add item</button>
          </div>
        </div>
        <div className="form-group"><label className="label">Notes</label><textarea className="input" rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
      </Modal>
    </PageShell>
  )
}
