import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, StatusBadge } from '../../components/ui/LoadingScreen'
import { BookOpen, Plus, Edit2, Eye } from 'lucide-react'
import { format } from 'date-fns'

export default function BlogPage() {
  const { tenantId } = useTenant()
  const posts = useQuery(api.operations.listBlogPosts, { tenantId })
  const createPost = useMutation(api.operations.createBlogPost)

  const [showNew, setShowNew] = useState(false)
  const [preview, setPreview] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({ title: '', slug: '', content: '', excerpt: '', status: 'draft' as const, tags: '' })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const val = e.target.value
    setForm(f => ({
      ...f,
      [k]: val,
      ...(k === 'title' ? { slug: val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') } : {}),
    }))
  }

  const handleSave = async () => {
    if (!form.title.trim() || !form.content.trim()) return
    setSaving(true)
    try {
      await createPost({
        tenantId,
        title: form.title,
        slug: form.slug,
        content: form.content,
        excerpt: form.excerpt || undefined,
        status: form.status,
        tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : undefined,
      })
      setShowNew(false)
      setForm({ title: '', slug: '', content: '', excerpt: '', status: 'draft', tags: '' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <PageShell
      title="Blog & News"
      actions={<button className="btn-primary flex items-center gap-2" onClick={() => setShowNew(true)}><Plus size={16} />New Post</button>}
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {!posts || posts.length === 0 ? (
          <div className="col-span-3">
            <div className="card">
              <EmptyState icon={BookOpen} title="No posts yet" description="Publish news and updates for your funeral home." action={<button className="btn-primary" onClick={() => setShowNew(true)}>Write First Post</button>} />
            </div>
          </div>
        ) : (
          [...posts].sort((a, b) => b.createdAt - a.createdAt).map(post => (
            <div key={post._id} className="card flex flex-col">
              {post.coverImageUrl && (
                <div className="h-40 bg-struta-100 rounded-t-lg overflow-hidden">
                  <img src={post.coverImageUrl} alt="" className="w-full h-full object-cover" />
                </div>
              )}
              <div className="p-5 flex flex-col flex-1">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h3 className="font-sans font-semibold text-struta-900 text-base leading-snug flex-1">{post.title}</h3>
                  <StatusBadge status={post.status} />
                </div>
                {post.excerpt && <p className="text-sm text-struta-500 mb-3 flex-1 line-clamp-2">{post.excerpt}</p>}
                {post.tags && post.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {post.tags.map(t => <span key={t} className="badge badge-gray text-xs">{t}</span>)}
                  </div>
                )}
                <div className="flex items-center justify-between mt-auto pt-3 border-t border-struta-100">
                  <span className="text-xs text-struta-400">{format(new Date(post.createdAt), 'dd MMM yyyy')}</span>
                  <button className="btn-ghost flex items-center gap-1 text-xs py-1" onClick={() => setPreview(post)}>
                    <Eye size={12} /> Preview
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* New Post Modal */}
      <Modal open={showNew} onClose={() => setShowNew(false)} title="New Blog Post" size="lg"
        footer={
          <>
            <button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button>
            <button className="btn-secondary" onClick={() => { setForm(f => ({ ...f, status: 'draft' })); handleSave() }}>Save Draft</button>
            <button className="btn-primary" onClick={() => { setForm(f => ({ ...f, status: 'published' })); handleSave() }} disabled={saving}>{saving ? 'Publishing…' : 'Publish'}</button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="form-group">
            <label className="label">Title <span className="text-red-500">*</span></label>
            <input className="input" value={form.title} onChange={set('title')} placeholder="Post title" autoFocus />
          </div>
          <div className="form-group">
            <label className="label">URL Slug</label>
            <input className="input font-mono text-sm" value={form.slug} onChange={set('slug')} />
          </div>
          <div className="form-group">
            <label className="label">Excerpt</label>
            <textarea className="input resize-none" rows={2} value={form.excerpt} onChange={set('excerpt')} placeholder="Short summary shown in post listings…" />
          </div>
          <div className="form-group">
            <label className="label">Content <span className="text-red-500">*</span></label>
            <textarea className="input resize-none" rows={10} value={form.content} onChange={set('content')} placeholder="Write your post content here…" />
          </div>
          <div className="form-group">
            <label className="label">Tags</label>
            <input className="input" value={form.tags} onChange={set('tags')} placeholder="e.g. news, memorial, community" />
            <p className="text-xs text-struta-400 mt-1">Separate tags with commas</p>
          </div>
        </div>
      </Modal>

      {/* Preview Modal */}
      {preview && (
        <Modal open={!!preview} onClose={() => setPreview(null)} title={preview.title} size="lg"
          footer={<button className="btn-secondary" onClick={() => setPreview(null)}>Close</button>}
        >
          <article className="prose prose-sm max-w-none">
            {preview.excerpt && <p className="text-struta-500 italic mb-4">{preview.excerpt}</p>}
            <div className="whitespace-pre-wrap text-struta-800 text-sm leading-relaxed">{preview.content}</div>
            {preview.tags?.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-4 pt-4 border-t border-struta-100">
                {preview.tags.map((t: string) => <span key={t} className="badge badge-gray">{t}</span>)}
              </div>
            )}
          </article>
        </Modal>
      )}
    </PageShell>
  )
}
