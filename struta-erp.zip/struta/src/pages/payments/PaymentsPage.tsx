import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal } from '../../components/ui/LoadingScreen'
import { CreditCard, Plus } from 'lucide-react'
import { format } from 'date-fns'

const METHODS = ['cash', 'bank_transfer', 'paypal', 'mpesa', 'card', 'cheque', 'other']

export default function PaymentsPage() {
  const { tenantId } = useTenant()
  const payments = useQuery(api.data.listPayments, { tenantId })
  const invoices = useQuery(api.data.listInvoices, { tenantId })
  const recordPayment = useMutation(api.data.recordPayment)

  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ invoiceId: '', amount: '', currency: 'KES', method: 'cash', reference: '', mpesaCode: '', notes: '' })
  const [saving, setSaving] = useState(false)

  const unpaidInvoices = (invoices ?? []).filter(i => i.status !== 'paid' && i.status !== 'cancelled')

  async function handleRecord() {
    if (!form.invoiceId || !form.amount) return
    setSaving(true)
    try {
      await recordPayment({ tenantId, invoiceId: form.invoiceId as any, amount: Number(form.amount), currency: form.currency, method: form.method as any, reference: form.reference || undefined, mpesaCode: form.mpesaCode || undefined, notes: form.notes || undefined })
      setShowNew(false)
      setForm({ invoiceId: '', amount: '', currency: 'KES', method: 'cash', reference: '', mpesaCode: '', notes: '' })
    } finally { setSaving(false) }
  }

  const total = (payments ?? []).reduce((s, p) => s + p.amount, 0)

  return (
    <PageShell title="Payments" actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Record Payment</button>}>
      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="stat-card"><p className="text-xs text-struta-500 uppercase tracking-wide">Total Received</p><p className="text-2xl font-bold text-green-700 mt-1">KES {total.toLocaleString()}</p></div>
        <div className="stat-card"><p className="text-xs text-struta-500 uppercase tracking-wide">Transactions</p><p className="text-2xl font-bold text-struta-900 mt-1">{payments?.length ?? 0}</p></div>
        <div className="stat-card"><p className="text-xs text-struta-500 uppercase tracking-wide">Unpaid Invoices</p><p className="text-2xl font-bold text-yellow-700 mt-1">{unpaidInvoices.length}</p></div>
      </div>

      {!payments ? <p className="text-sm text-struta-400">Loading…</p>
        : payments.length === 0 ? (
          <EmptyState icon={CreditCard} title="No payments recorded" description="Record client payments against invoices." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Record Payment</button>} />
        ) : (
          <div className="table-wrapper">
            <table className="table">
              <thead><tr><th>Date</th><th>Invoice</th><th>Method</th><th>Reference</th><th>Amount</th></tr></thead>
              <tbody>
                {[...payments].sort((a, b) => b.createdAt - a.createdAt).map(p => (
                  <tr key={p._id}>
                    <td>{format(new Date(p.paidAt), 'd MMM yyyy')}</td>
                    <td className="text-struta-600 font-mono text-xs">{p.invoiceId}</td>
                    <td><span className="badge badge-gray capitalize">{p.method.replace(/_/g, ' ')}</span></td>
                    <td className="text-struta-400 font-mono text-xs">{p.mpesaCode ?? p.reference ?? '—'}</td>
                    <td className="font-semibold text-green-700">{p.currency} {p.amount.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Record Payment"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleRecord} disabled={saving || !form.invoiceId || !form.amount}>{saving ? 'Recording…' : 'Record'}</button></>}>
        <div className="form-group">
          <label className="label">Invoice *</label>
          <select className="select" value={form.invoiceId} onChange={e => setForm(f => ({ ...f, invoiceId: e.target.value }))}>
            <option value="">Select invoice…</option>
            {unpaidInvoices.map(i => <option key={i._id} value={i._id}>{i.invoiceNumber} — KES {(i.total - i.paidAmount).toLocaleString()} outstanding</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">Amount *</label><input type="number" className="input" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Currency</label><select className="select" value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))}><option>KES</option><option>USD</option></select></div>
        </div>
        <div className="form-group">
          <label className="label">Payment Method</label>
          <select className="select" value={form.method} onChange={e => setForm(f => ({ ...f, method: e.target.value }))}>
            {METHODS.map(m => <option key={m} value={m}>{m.replace(/_/g, ' ')}</option>)}
          </select>
        </div>
        {form.method === 'mpesa' && <div className="form-group"><label className="label">M-Pesa Code</label><input className="input font-mono" value={form.mpesaCode} onChange={e => setForm(f => ({ ...f, mpesaCode: e.target.value }))} placeholder="e.g. RDK7XXXXXX" /></div>}
        {['bank_transfer', 'cheque', 'paypal'].includes(form.method) && <div className="form-group"><label className="label">Reference</label><input className="input" value={form.reference} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))} /></div>}
        <div className="form-group"><label className="label">Notes</label><textarea className="input" rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
      </Modal>
    </PageShell>
  )
}
