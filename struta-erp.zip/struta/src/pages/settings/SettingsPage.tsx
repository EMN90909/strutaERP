import { useState, useEffect } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, Alert } from '../../components/ui/LoadingScreen'
import { Settings, Users, Building2, Shield } from 'lucide-react'
import clsx from 'clsx'

const TABS = [
  { id: 'general', label: 'General', icon: Building2 },
  { id: 'users', label: 'Users & Roles', icon: Users },
  { id: 'security', label: 'Security', icon: Shield },
]

const ROLES = ['owner', 'admin', 'manager', 'staff', 'finance', 'support', 'readonly'] as const

function GeneralSettings() {
  const { tenantId, tenant } = useTenant()
  const updateSettings = useMutation(api.tenants.updateTenantSettings)
  const [form, setForm] = useState({ name: '', phone: '', address: '', city: '', country: '', website: '' })
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  useEffect(() => {
    if (tenant) {
      setForm({
        name: tenant.name ?? '',
        phone: tenant.phone ?? '',
        address: tenant.address ?? '',
        city: tenant.city ?? '',
        country: tenant.country ?? '',
        website: tenant.website ?? '',
      })
    }
  }, [tenant])

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSave = async () => {
    setSaving(true)
    setMsg(null)
    try {
      await updateSettings({ tenantId, ...form })
      setMsg({ type: 'success', text: 'Settings saved successfully.' })
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message ?? 'Failed to save settings.' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="card p-6 max-w-xl">
      <h3 className="font-sans font-semibold text-struta-800 mb-5">Funeral Home Details</h3>
      <div className="grid grid-cols-2 gap-4">
        <div className="form-group col-span-2">
          <label className="label">Funeral Home Name</label>
          <input className="input" value={form.name} onChange={set('name')} />
        </div>
        <div className="form-group">
          <label className="label">Phone Number</label>
          <input className="input" type="tel" value={form.phone} onChange={set('phone')} placeholder="+254 700 000 000" />
        </div>
        <div className="form-group">
          <label className="label">Website</label>
          <input className="input" type="url" value={form.website} onChange={set('website')} placeholder="https://yourfuneralhome.com" />
        </div>
        <div className="form-group col-span-2">
          <label className="label">Street Address</label>
          <input className="input" value={form.address} onChange={set('address')} placeholder="123 Memorial Lane" />
        </div>
        <div className="form-group">
          <label className="label">City</label>
          <input className="input" value={form.city} onChange={set('city')} placeholder="Nairobi" />
        </div>
        <div className="form-group">
          <label className="label">Country</label>
          <input className="input" value={form.country} onChange={set('country')} placeholder="Kenya" />
        </div>
      </div>
      {msg && <div className="mb-4"><Alert type={msg.type} message={msg.text} /></div>}
      <button className="btn-primary" onClick={handleSave} disabled={saving}>
        {saving ? 'Saving…' : 'Save Changes'}
      </button>
    </div>
  )
}

function UsersSettings() {
  const { tenantId, hasRole } = useTenant()
  const users = useQuery(api.tenants.getTenantUsers, { tenantId })
  const inviteUser = useMutation(api.tenants.inviteUser)
  const [showInvite, setShowInvite] = useState(false)
  const [form, setForm] = useState({ email: '', name: '', role: 'staff' as const })
  const [saving, setSaving] = useState(false)
  const canManage = hasRole(['owner', 'admin'])

  const handleInvite = async () => {
    if (!form.email || !form.name) return
    setSaving(true)
    try {
      await inviteUser({ tenantId, ...form, clerkId: `pending_${Date.now()}` })
      setShowInvite(false)
      setForm({ email: '', name: '', role: 'staff' })
    } finally {
      setSaving(false)
    }
  }

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  return (
    <div className="space-y-5">
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-struta-100 flex items-center justify-between">
          <h3 className="font-sans font-semibold text-struta-800">Team Members</h3>
          {canManage && (
            <button className="btn-primary text-sm" onClick={() => setShowInvite(s => !s)}>
              {showInvite ? 'Cancel' : 'Invite User'}
            </button>
          )}
        </div>

        {showInvite && (
          <div className="px-5 py-4 bg-struta-50 border-b border-struta-100">
            <div className="grid grid-cols-3 gap-3 max-w-xl">
              <div className="form-group">
                <label className="label">Full Name</label>
                <input className="input" value={form.name} onChange={set('name')} placeholder="Jane Doe" />
              </div>
              <div className="form-group">
                <label className="label">Email</label>
                <input className="input" type="email" value={form.email} onChange={set('email')} placeholder="jane@example.com" />
              </div>
              <div className="form-group">
                <label className="label">Role</label>
                <select className="select" value={form.role} onChange={set('role')}>
                  {ROLES.filter(r => r !== 'owner').map(r => (
                    <option key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</option>
                  ))}
                </select>
              </div>
            </div>
            <p className="text-xs text-struta-500 mb-3">The invited user will need to sign up with this email address.</p>
            <button className="btn-primary text-sm" onClick={handleInvite} disabled={saving}>
              {saving ? 'Inviting…' : 'Send Invite'}
            </button>
          </div>
        )}

        <table className="w-full text-sm">
          <thead className="table-header">
            <tr>
              {['Name', 'Email', 'Role', 'Status'].map(h => (
                <th key={h} className="px-5 py-3 text-left text-xs font-semibold text-struta-500 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(users ?? []).map(u => (
              <tr key={u._id} className="table-row">
                <td className="px-5 py-3 font-medium text-struta-800">{u.name}</td>
                <td className="px-5 py-3 text-struta-500">{u.email}</td>
                <td className="px-5 py-3">
                  <span className="badge badge-blue capitalize">{u.role}</span>
                </td>
                <td className="px-5 py-3">
                  <span className={u.isActive ? 'badge-green' : 'badge-red'}>{u.isActive ? 'Active' : 'Inactive'}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card p-6 max-w-lg">
        <h3 className="font-sans font-semibold text-struta-800 mb-3">Role Permissions</h3>
        <div className="space-y-3 text-sm text-struta-600">
          {[
            { role: 'Owner', desc: 'Full access to all settings, billing, and user management.' },
            { role: 'Admin', desc: 'All access except billing changes. Can manage users.' },
            { role: 'Manager', desc: 'Can manage cases, contacts, employees, and view reports.' },
            { role: 'Staff', desc: 'Can log timesheets, update cases, and view contacts.' },
            { role: 'Finance', desc: 'Access to invoices, payments, and financial reports.' },
            { role: 'Support', desc: 'Can view cases and contacts. Read-only on finance.' },
            { role: 'Readonly', desc: 'View access only across all modules.' },
          ].map(({ role, desc }) => (
            <div key={role} className="flex gap-3">
              <span className="badge badge-gray flex-shrink-0 w-24 justify-center">{role}</span>
              <span>{desc}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function SecuritySettings() {
  const { tenant } = useTenant()
  return (
    <div className="card p-6 max-w-xl">
      <h3 className="font-sans font-semibold text-struta-800 mb-4">Security Information</h3>
      <div className="space-y-4 text-sm text-struta-600">
        <div className="flex items-start gap-3 p-4 rounded-lg bg-struta-50">
          <Shield size={16} className="text-struta-500 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium text-struta-800">Tenant Isolation</p>
            <p className="mt-0.5">All your data is strictly isolated from other funeral homes on Struta. No data is ever shared between tenants.</p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-4 rounded-lg bg-struta-50">
          <Shield size={16} className="text-struta-500 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium text-struta-800">Authentication</p>
            <p className="mt-0.5">Login is secured via Clerk. All sessions are authenticated and access-controlled by role.</p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-4 rounded-lg bg-struta-50">
          <Shield size={16} className="text-struta-500 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium text-struta-800">Workspace ID</p>
            <p className="mt-1 font-mono bg-white border border-struta-200 rounded px-3 py-1.5 text-struta-800">{tenant?.slug ?? '—'}</p>
          </div>
        </div>
        <p className="text-struta-400 text-xs">For security concerns, contact <a href="mailto:security@struta.app" className="underline">security@struta.app</a></p>
      </div>
    </div>
  )
}

export default function SettingsPage() {
  const [tab, setTab] = useState('general')

  return (
    <PageShell title="Settings">
      <div className="flex gap-1 mb-6 border-b border-struta-200">
        {TABS.map(t => {
          const Icon = t.icon
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={clsx(
                'flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors',
                tab === t.id
                  ? 'border-struta-700 text-struta-900'
                  : 'border-transparent text-struta-500 hover:text-struta-700'
              )}
            >
              <Icon size={15} />
              {t.label}
            </button>
          )
        })}
      </div>
      {tab === 'general' && <GeneralSettings />}
      {tab === 'users' && <UsersSettings />}
      {tab === 'security' && <SecuritySettings />}
    </PageShell>
  )
}
