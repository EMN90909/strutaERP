import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, SearchInput, StatusBadge } from '../../components/ui/LoadingScreen'
import { Users, Plus } from 'lucide-react'

const TYPES = [
  { value: '', label: 'All' },
  { value: 'family', label: 'Families' },
  { value: 'supplier', label: 'Suppliers' },
  { value: 'partner', label: 'Partners' },
  { value: 'other', label: 'Other' },
]

export default function ContactsPage() {
  const { tenantId } = useTenant()
  const contacts = useQuery(api.data.listContacts, { tenantId })
  const createContact = useMutation(api.data.createContact)

  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ type: 'family' as const, firstName: '', lastName: '', email: '', phone: '', address: '', city: '', country: 'Kenya', notes: '' })
  const [saving, setSaving] = useState(false)

  const filtered = (contacts ?? []).filter(c => {
    const name = `${c.firstName} ${c.lastName}`.toLowerCase()
    const matchSearch = !search || name.includes(search.toLowerCase()) || c.email?.includes(search) || c.phone?.includes(search)
    const matchType = !typeFilter || c.type === typeFilter
    return matchSearch && matchType
  })

  async function handleCreate() {
    if (!form.firstName || !form.lastName) return
    setSaving(true)
    try {
      await createContact({ tenantId, ...form, email: form.email || undefined, phone: form.phone || undefined, address: form.address || undefined, city: form.city || undefined, country: form.country || undefined, notes: form.notes || undefined })
      setShowNew(false)
      setForm({ type: 'family', firstName: '', lastName: '', email: '', phone: '', address: '', city: '', country: 'Kenya', notes: '' })
    } finally { setSaving(false) }
  }

  return (
    <PageShell
      title="Contacts"
      actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Add Contact</button>}
    >
      <div className="flex flex-wrap gap-3 mb-5">
        <SearchInput value={search} onChange={setSearch} placeholder="Search contacts…" />
        <div className="flex gap-1">
          {TYPES.map(t => (
            <button key={t.value} onClick={() => setTypeFilter(t.value)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${typeFilter === t.value ? 'bg-struta-600 text-white' : 'bg-white border border-struta-200 text-struta-600 hover:border-struta-400'}`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {!contacts ? (
        <p className="text-sm text-struta-400">Loading…</p>
      ) : filtered.length === 0 ? (
        <EmptyState icon={Users} title="No contacts found" description="Add families, suppliers, and partners here." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Add Contact</button>} />
      ) : (
        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Phone</th>
                <th>Email</th>
                <th>City</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c._id}>
                  <td className="font-medium text-struta-900">{c.firstName} {c.lastName}</td>
                  <td><span className={`badge ${c.type === 'family' ? 'badge-purple' : c.type === 'supplier' ? 'badge-blue' : 'badge-gray'}`}>{c.type}</span></td>
                  <td>{c.phone ?? <span className="text-struta-300">—</span>}</td>
                  <td>{c.email ?? <span className="text-struta-300">—</span>}</td>
                  <td>{c.city ?? <span className="text-struta-300">—</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Add Contact"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleCreate} disabled={saving || !form.firstName || !form.lastName}>{saving ? 'Saving…' : 'Save Contact'}</button></>}
      >
        <div className="form-group">
          <label className="label">Contact Type</label>
          <select className="select" value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value as any }))}>
            <option value="family">Family / Client</option>
            <option value="supplier">Supplier</option>
            <option value="partner">Partner</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">First Name *</label><input className="input" value={form.firstName} onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Last Name *</label><input className="input" value={form.lastName} onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} /></div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">Phone</label><input className="input" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+254…" /></div>
          <div className="form-group"><label className="label">Email</label><input type="email" className="input" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">City</label><input className="input" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Country</label><input className="input" value={form.country} onChange={e => setForm(f => ({ ...f, country: e.target.value }))} /></div>
        </div>
        <div className="form-group"><label className="label">Notes</label><textarea className="input" rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
      </Modal>
    </PageShell>
  )
}
