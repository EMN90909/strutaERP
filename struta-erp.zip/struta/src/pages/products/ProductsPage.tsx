// Products Page
import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, SearchInput } from '../../components/ui/LoadingScreen'
import { Package, Plus } from 'lucide-react'

const CATEGORIES = ['casket', 'service', 'package', 'flowers', 'transport', 'venue', 'other']

export default function ProductsPage() {
  const { tenantId } = useTenant()
  const products = useQuery(api.data.listProducts, { tenantId })
  const createProduct = useMutation(api.data.createProduct)

  const [search, setSearch] = useState('')
  const [catFilter, setCatFilter] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ name: '', description: '', category: 'casket' as const, price: '', costPrice: '', sku: '', taxRate: '', unit: 'unit' })
  const [saving, setSaving] = useState(false)

  const filtered = (products ?? []).filter(p => {
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase())
    const matchCat = !catFilter || p.category === catFilter
    return matchSearch && matchCat
  })

  async function handleCreate() {
    if (!form.name || !form.price) return
    setSaving(true)
    try {
      await createProduct({ tenantId, name: form.name, description: form.description || undefined, category: form.category, price: Number(form.price), costPrice: form.costPrice ? Number(form.costPrice) : undefined, sku: form.sku || undefined, taxRate: form.taxRate ? Number(form.taxRate) : undefined, unit: form.unit || undefined })
      setShowNew(false)
      setForm({ name: '', description: '', category: 'casket', price: '', costPrice: '', sku: '', taxRate: '', unit: 'unit' })
    } finally { setSaving(false) }
  }

  return (
    <PageShell title="Products & Services" actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Add Product</button>}>
      <div className="flex flex-wrap gap-3 mb-5">
        <SearchInput value={search} onChange={setSearch} placeholder="Search products…" />
        <select className="select w-auto" value={catFilter} onChange={e => setCatFilter(e.target.value)}>
          <option value="">All categories</option>
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {!products ? <p className="text-sm text-struta-400">Loading…</p>
        : filtered.length === 0 ? (
          <EmptyState icon={Package} title="No products yet" description="Add caskets, services, packages, and more." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Add Product</button>} />
        ) : (
          <div className="table-wrapper">
            <table className="table">
              <thead><tr><th>Name</th><th>Category</th><th>SKU</th><th>Price (KES)</th><th>Cost (KES)</th><th>Tax %</th></tr></thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p._id}>
                    <td className="font-medium text-struta-900">{p.name}</td>
                    <td><span className="badge badge-gray capitalize">{p.category}</span></td>
                    <td className="text-struta-400 font-mono text-xs">{p.sku ?? '—'}</td>
                    <td className="font-medium">{p.price.toLocaleString()}</td>
                    <td>{p.costPrice?.toLocaleString() ?? '—'}</td>
                    <td>{p.taxRate ? `${p.taxRate}%` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Add Product / Service"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleCreate} disabled={saving || !form.name}>{saving ? 'Saving…' : 'Save'}</button></>}>
        <div className="form-group"><label className="label">Name *</label><input className="input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Premium Oak Casket" /></div>
        <div className="form-group">
          <label className="label">Category</label>
          <select className="select" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as any }))}>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">Selling Price (KES) *</label><input type="number" className="input" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Cost Price (KES)</label><input type="number" className="input" value={form.costPrice} onChange={e => setForm(f => ({ ...f, costPrice: e.target.value }))} /></div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">SKU</label><input className="input" value={form.sku} onChange={e => setForm(f => ({ ...f, sku: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Tax Rate (%)</label><input type="number" className="input" value={form.taxRate} onChange={e => setForm(f => ({ ...f, taxRate: e.target.value }))} placeholder="0" /></div>
        </div>
        <div className="form-group"><label className="label">Description</label><textarea className="input" rows={2} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} /></div>
      </Modal>
    </PageShell>
  )
}
