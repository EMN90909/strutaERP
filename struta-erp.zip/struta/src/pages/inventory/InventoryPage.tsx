import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal } from '../../components/ui/LoadingScreen'
import { Archive, AlertTriangle, Plus } from 'lucide-react'

export default function InventoryPage() {
  const { tenantId } = useTenant()
  const inventory = useQuery(api.data.listInventory, { tenantId })
  const products = useQuery(api.data.listProducts, { tenantId })
  const updateInventory = useMutation(api.data.updateInventory)

  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ productId: '', location: 'Main Branch', quantity: '', minQuantity: '' })
  const [saving, setSaving] = useState(false)

  const lowStock = (inventory ?? []).filter(i => i.minQuantity && i.quantity <= i.minQuantity)

  async function handleSave() {
    if (!form.productId || !form.quantity) return
    setSaving(true)
    try {
      await updateInventory({ tenantId, productId: form.productId as any, location: form.location, quantity: Number(form.quantity), minQuantity: form.minQuantity ? Number(form.minQuantity) : undefined })
      setShowNew(false)
      setForm({ productId: '', location: 'Main Branch', quantity: '', minQuantity: '' })
    } finally { setSaving(false) }
  }

  return (
    <PageShell title="Inventory" actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Update Stock</button>}>
      {lowStock.length > 0 && (
        <div className="mb-5 flex items-start gap-3 p-4 rounded-xl bg-red-50 border border-red-200">
          <AlertTriangle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-red-800">
            <strong>{lowStock.length} item{lowStock.length > 1 ? 's' : ''}</strong> at or below minimum stock level.
            <ul className="mt-1 list-disc list-inside text-xs">
              {lowStock.map(i => <li key={i._id}>{i.product?.name} — {i.quantity} remaining</li>)}
            </ul>
          </div>
        </div>
      )}

      {!inventory ? <p className="text-sm text-struta-400">Loading…</p>
        : inventory.length === 0 ? (
          <EmptyState icon={Archive} title="No inventory records" description="Track stock of caskets and supplies across locations." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Add Stock</button>} />
        ) : (
          <div className="table-wrapper">
            <table className="table">
              <thead><tr><th>Product</th><th>Category</th><th>Location</th><th>Quantity</th><th>Min Level</th><th>Status</th></tr></thead>
              <tbody>
                {inventory.map(i => {
                  const isLow = i.minQuantity && i.quantity <= i.minQuantity
                  return (
                    <tr key={i._id}>
                      <td className="font-medium text-struta-900">{i.product?.name ?? '—'}</td>
                      <td><span className="badge badge-gray capitalize">{i.product?.category ?? '—'}</span></td>
                      <td>{i.location}</td>
                      <td className={`font-medium ${isLow ? 'text-red-700' : 'text-struta-900'}`}>{i.quantity}</td>
                      <td>{i.minQuantity ?? '—'}</td>
                      <td>{isLow ? <span className="badge badge-red">Low Stock</span> : <span className="badge badge-green">OK</span>}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Update Stock"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleSave} disabled={saving || !form.productId}>{saving ? 'Saving…' : 'Save'}</button></>}>
        <div className="form-group">
          <label className="label">Product *</label>
          <select className="select" value={form.productId} onChange={e => setForm(f => ({ ...f, productId: e.target.value }))}>
            <option value="">Select product…</option>
            {(products ?? []).map(p => <option key={p._id} value={p._id}>{p.name}</option>)}
          </select>
        </div>
        <div className="form-group"><label className="label">Location</label><input className="input" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">Quantity *</label><input type="number" className="input" value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Min Level Alert</label><input type="number" className="input" value={form.minQuantity} onChange={e => setForm(f => ({ ...f, minQuantity: e.target.value }))} placeholder="e.g. 2" /></div>
        </div>
      </Modal>
    </PageShell>
  )
}
