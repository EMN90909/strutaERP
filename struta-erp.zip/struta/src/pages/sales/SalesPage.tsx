import { useTenant } from '../../contexts/TenantContext'
import { useQuery } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { PageShell, EmptyState, StatusBadge } from '../../components/ui/LoadingScreen'
import { TrendingUp, Link } from 'lucide-react'
import { Link as RouterLink } from 'react-router-dom'

export default function SalesPage() {
  const { tenantId } = useTenant()
  const cases = useQuery(api.cases.listCases, { tenantId })

  const pipeline = cases ?? []
  const stages = ['lead', 'consultation', 'quoted', 'booked', 'in_progress', 'completed']

  return (
    <PageShell title="Sales Pipeline">
      <p className="text-sm text-struta-500 mb-5">Track cases from initial lead through to completed service.</p>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {stages.map(stage => {
          const count = pipeline.filter(c => c.status === stage).length
          return (
            <div key={stage} className="card text-center">
              <p className="text-xs text-struta-400 uppercase tracking-wide mb-1">{stage.replace(/_/g, ' ')}</p>
              <p className="text-2xl font-bold font-sans text-struta-800">{count}</p>
            </div>
          )
        })}
      </div>

      {pipeline.length === 0 ? (
        <EmptyState icon={TrendingUp} title="No cases in pipeline" description="Create cases to track your sales pipeline." action={<RouterLink to="/cases" className="btn-primary"><TrendingUp size={15} /> Go to Cases</RouterLink>} />
      ) : (
        <div className="table-wrapper">
          <table className="table">
            <thead><tr><th>Case</th><th>Deceased</th><th>Service Date</th><th>Value (KES)</th><th>Stage</th></tr></thead>
            <tbody>
              {[...pipeline].sort((a, b) => b.createdAt - a.createdAt).slice(0, 50).map(c => (
                <tr key={c._id}>
                  <td><RouterLink to={`/cases/${c._id}`} className="text-struta-600 hover:underline font-medium">{c.caseNumber}</RouterLink></td>
                  <td className="text-struta-900 font-medium">{c.deceasedName}</td>
                  <td>{c.serviceDate ?? <span className="text-struta-300">TBD</span>}</td>
                  <td>{c.totalValue ? c.totalValue.toLocaleString() : <span className="text-struta-300">—</span>}</td>
                  <td><StatusBadge status={c.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </PageShell>
  )
}
