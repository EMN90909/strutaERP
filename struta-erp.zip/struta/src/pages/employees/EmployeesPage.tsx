import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, SearchInput, StatusBadge } from '../../components/ui/LoadingScreen'
import { UserCheck, Plus } from 'lucide-react'

export default function EmployeesPage() {
  const { tenantId } = useTenant()
  const employees = useQuery(api.data.listEmployees, { tenantId })
  const createEmployee = useMutation(api.data.createEmployee)

  const [search, setSearch] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', role: '', department: '', startDate: '', salary: '' })
  const [saving, setSaving] = useState(false)

  const filtered = (employees ?? []).filter(e => {
    const name = `${e.firstName} ${e.lastName}`.toLowerCase()
    return !search || name.includes(search.toLowerCase()) || e.email.includes(search) || e.role.toLowerCase().includes(search.toLowerCase())
  })

  async function handleCreate() {
    if (!form.firstName || !form.lastName || !form.email || !form.role) return
    setSaving(true)
    try {
      await createEmployee({ tenantId, firstName: form.firstName, lastName: form.lastName, email: form.email, phone: form.phone || undefined, role: form.role, department: form.department || undefined, startDate: form.startDate || undefined, salary: form.salary ? Number(form.salary) : undefined })
      setShowNew(false)
      setForm({ firstName: '', lastName: '', email: '', phone: '', role: '', department: '', startDate: '', salary: '' })
    } finally { setSaving(false) }
  }

  return (
    <PageShell title="Employees" actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Add Employee</button>}>
      <div className="mb-5"><SearchInput value={search} onChange={setSearch} placeholder="Search staff…" /></div>

      {!employees ? <p className="text-sm text-struta-400">Loading…</p>
        : filtered.length === 0 ? (
          <EmptyState icon={UserCheck} title="No employees found" description="Add your funeral home staff members." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> Add Employee</button>} />
        ) : (
          <div className="table-wrapper">
            <table className="table">
              <thead><tr><th>Name</th><th>Role</th><th>Department</th><th>Email</th><th>Phone</th><th>Status</th></tr></thead>
              <tbody>
                {filtered.map(e => (
                  <tr key={e._id}>
                    <td className="font-medium text-struta-900">{e.firstName} {e.lastName}</td>
                    <td>{e.role}</td>
                    <td>{e.department ?? <span className="text-struta-300">—</span>}</td>
                    <td className="text-struta-600">{e.email}</td>
                    <td>{e.phone ?? <span className="text-struta-300">—</span>}</td>
                    <td><StatusBadge status={e.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Add Employee"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleCreate} disabled={saving || !form.firstName || !form.email}>{saving ? 'Saving…' : 'Save'}</button></>}>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">First Name *</label><input className="input" value={form.firstName} onChange={e => setForm(f => ({ ...f, firstName: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Last Name *</label><input className="input" value={form.lastName} onChange={e => setForm(f => ({ ...f, lastName: e.target.value }))} /></div>
        </div>
        <div className="form-group"><label className="label">Email *</label><input type="email" className="input" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">Phone</label><input className="input" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
          <div className="form-group"><label className="label">Role *</label><input className="input" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))} placeholder="e.g. Embalmer, Driver" /></div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group"><label className="label">Department</label><input className="input" value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))} placeholder="e.g. Operations" /></div>
          <div className="form-group"><label className="label">Start Date</label><input type="date" className="input" value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} /></div>
        </div>
        <div className="form-group"><label className="label">Monthly Salary (KES)</label><input type="number" className="input" value={form.salary} onChange={e => setForm(f => ({ ...f, salary: e.target.value }))} /></div>
      </Modal>
    </PageShell>
  )
}
