import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, SearchInput, StatusBadge } from '../../components/ui/LoadingScreen'
import { FileText, Plus, Trash2 } from 'lucide-react'
import { format } from 'date-fns'

function currency(n: number) {
  return `KES ${n.toLocaleString('en-KE', { maximumFractionDigits: 0 })}`
}

export default function InvoicesPage() {
  const { tenantId } = useTenant()
  const invoices = useQuery(api.data.listInvoices, { tenantId })
  const contacts = useQuery(api.data.listContacts, { tenantId })
  const products = useQuery(api.data.listProducts, { tenantId })
  const createInvoice = useMutation(api.data.createInvoice)
  const updateStatus = useMutation(api.data.updateInvoiceStatus)

  const [search, setSearch] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    contactId: '', issueDate: new Date().toISOString().split('T')[0],
    dueDate: '', currency: 'KES', notes: '',
  })
  const [lineItems, setLineItems] = useState([{ description: '', quantity: 1, unitPrice: 0, taxRate: 0, total: 0 }])

  const filtered = (invoices ?? []).filter(i =>
    !search || i.invoiceNumber.toLowerCase().includes(search.toLowerCase())
  )

  function updateLine(idx: number, field: string, val: any) {
    setLineItems(items => items.map((item, i) => {
      if (i !== idx) return item
      const updated = { ...item, [field]: val }
      updated.total = updated.quantity * updated.unitPrice
      return updated
    }))
  }

  async function handleCreate() {
    if (!form.contactId || !form.dueDate) return
    setSaving(true)
    try {
      await createInvoice({
        tenantId,
        contactId: form.contactId as any,
        issueDate: form.issueDate,
        dueDate: form.dueDate,
        currency: form.currency,
        notes: form.notes || undefined,
        lineItems: lineItems.filter(l => l.description),
      })
      setShowNew(false)
      setForm({ contactId: '', issueDate: new Date().toISOString().split('T')[0], dueDate: '', currency: 'KES', notes: '' })
      setLineItems([{ description: '', quantity: 1, unitPrice: 0, taxRate: 0, total: 0 }])
    } finally { setSaving(false) }
  }

  const subtotal = lineItems.reduce((s, l) => s + l.total, 0)

  return (
    <PageShell title="Invoices" actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> New Invoice</button>}>
      <div className="mb-5"><SearchInput value={search} onChange={setSearch} placeholder="Search invoices…" /></div>

      {!invoices ? <p className="text-sm text-struta-400">Loading…</p>
        : filtered.length === 0 ? (
          <EmptyState icon={FileText} title="No invoices yet" description="Create invoices for funeral services." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> New Invoice</button>} />
        ) : (
          <div className="table-wrapper">
            <table className="table">
              <thead><tr><th>Invoice #</th><th>Client</th><th>Issue Date</th><th>Due Date</th><th>Total</th><th>Paid</th><th>Status</th><th></th></tr></thead>
              <tbody>
                {filtered.map(inv => (
                  <tr key={inv._id}>
                    <td className="font-medium text-struta-700">{inv.invoiceNumber}</td>
                    <td>{inv.contactId}</td>
                    <td>{format(new Date(inv.issueDate), 'd MMM yyyy')}</td>
                    <td>{format(new Date(inv.dueDate), 'd MMM yyyy')}</td>
                    <td className="font-medium">{currency(inv.total)}</td>
                    <td className="text-green-700">{currency(inv.paidAmount)}</td>
                    <td><StatusBadge status={inv.status} /></td>
                    <td>
                      {inv.status === 'draft' && (
                        <button className="text-xs text-struta-600 hover:underline" onClick={() => updateStatus({ tenantId, invoiceId: inv._id, status: 'sent' })}>Mark Sent</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      <Modal open={showNew} onClose={() => setShowNew(false)} title="New Invoice" size="lg"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleCreate} disabled={saving || !form.contactId}>{saving ? 'Creating…' : 'Create Invoice'}</button></>}>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group">
            <label className="label">Client / Family *</label>
            <select className="select" value={form.contactId} onChange={e => setForm(f => ({ ...f, contactId: e.target.value }))}>
              <option value="">Select contact…</option>
              {(contacts ?? []).map(c => <option key={c._id} value={c._id}>{c.firstName} {c.lastName}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="label">Currency</label>
            <select className="select" value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))}>
              <option>KES</option><option>USD</option><option>GBP</option>
            </select>
          </div>
          <div className="form-group">
            <label className="label">Issue Date</label>
            <input type="date" className="input" value={form.issueDate} onChange={e => setForm(f => ({ ...f, issueDate: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="label">Due Date *</label>
            <input type="date" className="input" value={form.dueDate} onChange={e => setForm(f => ({ ...f, dueDate: e.target.value }))} />
          </div>
        </div>

        <div className="mb-4">
          <label className="label mb-2">Line Items</label>
          <div className="border border-struta-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-struta-50">
                <tr><th className="px-3 py-2 text-left">Description</th><th className="px-3 py-2 text-right w-16">Qty</th><th className="px-3 py-2 text-right w-28">Unit Price</th><th className="px-3 py-2 text-right w-24">Total</th><th className="w-8"></th></tr>
              </thead>
              <tbody>
                {lineItems.map((item, idx) => (
                  <tr key={idx} className="border-t border-struta-100">
                    <td className="px-2 py-1"><input className="input text-xs py-1" value={item.description} onChange={e => updateLine(idx, 'description', e.target.value)} placeholder="e.g. Oak Casket" /></td>
                    <td className="px-2 py-1"><input type="number" className="input text-xs py-1 text-right" value={item.quantity} onChange={e => updateLine(idx, 'quantity', Number(e.target.value))} /></td>
                    <td className="px-2 py-1"><input type="number" className="input text-xs py-1 text-right" value={item.unitPrice} onChange={e => updateLine(idx, 'unitPrice', Number(e.target.value))} /></td>
                    <td className="px-3 py-2 text-right font-medium">{item.total.toLocaleString()}</td>
                    <td className="px-2"><button onClick={() => setLineItems(i => i.filter((_, j) => j !== idx))} className="text-struta-300 hover:text-red-500"><Trash2 size={13} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button className="w-full text-xs text-struta-500 hover:text-struta-700 py-2 border-t border-struta-100 hover:bg-struta-50" onClick={() => setLineItems(i => [...i, { description: '', quantity: 1, unitPrice: 0, taxRate: 0, total: 0 }])}>
              + Add line item
            </button>
          </div>
          <div className="text-right text-sm font-medium text-struta-900 mt-2">Total: {form.currency} {subtotal.toLocaleString()}</div>
        </div>

        <div className="form-group"><label className="label">Notes</label><textarea className="input" rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>
      </Modal>
    </PageShell>
  )
}
