import { useState, useRef, useEffect } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { Send, MessageSquare, Hash } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'
import clsx from 'clsx'

const CHANNELS = [
  { id: 'general', label: 'General' },
  { id: 'operations', label: 'Operations' },
  { id: 'finance', label: 'Finance' },
  { id: 'hr', label: 'HR' },
]

export default function MessagesPage() {
  const { tenantId, user } = useTenant()
  const [channel, setChannel] = useState('general')
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const messagesEnd = useRef<HTMLDivElement>(null)

  const messages = useQuery(api.operations.listMessages, { tenantId, channelId: channel, limit: 100 })
  const sendMessage = useMutation(api.operations.sendMessage)

  useEffect(() => {
    messagesEnd.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSend = async () => {
    const content = text.trim()
    if (!content) return
    setSending(true)
    setText('')
    try {
      await sendMessage({ tenantId, content, channelId: channel })
    } finally {
      setSending(false)
    }
  }

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <div className="flex h-full">
      {/* Sidebar channels */}
      <div className="w-48 flex-shrink-0 bg-struta-900 flex flex-col">
        <div className="px-4 py-4 border-b border-struta-800">
          <p className="text-struta-300 text-xs font-semibold uppercase tracking-wider">Staff Chat</p>
        </div>
        <nav className="flex-1 py-2 px-2">
          {CHANNELS.map(ch => (
            <button
              key={ch.id}
              onClick={() => setChannel(ch.id)}
              className={clsx(
                'w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors mb-0.5',
                channel === ch.id
                  ? 'bg-struta-700 text-white'
                  : 'text-struta-400 hover:text-struta-200 hover:bg-struta-800'
              )}
            >
              <Hash size={14} />
              {ch.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col min-w-0 bg-white">
        {/* Header */}
        <div className="h-14 border-b border-struta-200 flex items-center px-6 gap-3 flex-shrink-0">
          <Hash size={16} className="text-struta-400" />
          <span className="font-medium text-struta-800 capitalize">{CHANNELS.find(c => c.id === channel)?.label ?? channel}</span>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {messages === undefined ? (
            <div className="text-center text-struta-400 text-sm py-8">Loading…</div>
          ) : messages.length === 0 ? (
            <div className="text-center py-16">
              <MessageSquare size={32} className="text-struta-200 mx-auto mb-3" />
              <p className="text-struta-400 text-sm">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            messages.map((msg, i) => {
              const isMe = msg.senderId === user?._id
              const showSender = i === 0 || messages[i - 1]?.senderId !== msg.senderId
              return (
                <div key={msg._id} className={clsx('flex gap-3', isMe && 'flex-row-reverse')}>
                  {showSender && (
                    <div className="w-8 h-8 rounded-full bg-struta-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {(msg.sender?.name ?? '?').charAt(0).toUpperCase()}
                    </div>
                  )}
                  {!showSender && <div className="w-8 flex-shrink-0" />}
                  <div className={clsx('max-w-xs lg:max-w-md', isMe && 'items-end flex flex-col')}>
                    {showSender && (
                      <div className={clsx('flex items-baseline gap-2 mb-1', isMe && 'flex-row-reverse')}>
                        <span className="text-xs font-medium text-struta-700">{msg.sender?.name ?? 'Unknown'}</span>
                        <span className="text-xs text-struta-400">{formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}</span>
                      </div>
                    )}
                    <div className={clsx(
                      'px-4 py-2.5 rounded-2xl text-sm leading-relaxed',
                      isMe
                        ? 'bg-struta-700 text-white rounded-tr-sm'
                        : 'bg-struta-100 text-struta-800 rounded-tl-sm'
                    )}>
                      {msg.content}
                    </div>
                  </div>
                </div>
              )
            })
          )}
          <div ref={messagesEnd} />
        </div>

        {/* Input */}
        <div className="border-t border-struta-200 px-6 py-4 flex-shrink-0">
          <div className="flex items-end gap-3">
            <textarea
              className="input flex-1 resize-none"
              rows={1}
              value={text}
              onChange={e => setText(e.target.value)}
              onKeyDown={handleKey}
              placeholder={`Message #${CHANNELS.find(c => c.id === channel)?.label ?? channel}…`}
              style={{ maxHeight: '120px', overflowY: text.split('\n').length > 3 ? 'auto' : 'hidden' }}
            />
            <button
              className="btn-primary flex items-center gap-2 flex-shrink-0"
              onClick={handleSend}
              disabled={sending || !text.trim()}
            >
              <Send size={14} />
              Send
            </button>
          </div>
          <p className="text-xs text-struta-400 mt-1.5">Press Enter to send, Shift+Enter for new line</p>
        </div>
      </div>
    </div>
  )
}
