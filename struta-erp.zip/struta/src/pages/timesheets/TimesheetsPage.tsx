import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, EmptyState, Modal, StatusBadge } from '../../components/ui/LoadingScreen'
import { Clock, Plus } from 'lucide-react'
import { format } from 'date-fns'

export default function TimesheetsPage() {
  const { tenantId } = useTenant()
  const timesheets = useQuery(api.operations.listTimesheets, { tenantId })
  const employees = useQuery(api.data.listEmployees, { tenantId })
  const cases = useQuery(api.cases.listCases, { tenantId })
  const logTime = useMutation(api.operations.logTime)

  const [showNew, setShowNew] = useState(false)
  const [saving, setSaving] = useState(false)
  const [form, setForm] = useState({
    employeeId: '',
    caseId: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    startTime: '08:00',
    endTime: '17:00',
    hours: '',
    description: '',
  })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSave = async () => {
    if (!form.employeeId || !form.date) return
    setSaving(true)
    try {
      await logTime({
        tenantId,
        employeeId: form.employeeId as any,
        caseId: form.caseId ? (form.caseId as any) : undefined,
        date: form.date,
        startTime: form.startTime,
        endTime: form.endTime || undefined,
        hours: form.hours ? parseFloat(form.hours) : undefined,
        description: form.description || undefined,
      })
      setShowNew(false)
      setForm({ employeeId: '', caseId: '', date: format(new Date(), 'yyyy-MM-dd'), startTime: '08:00', endTime: '17:00', hours: '', description: '' })
    } finally {
      setSaving(false)
    }
  }

  const empMap = Object.fromEntries((employees ?? []).map(e => [e._id, `${e.firstName} ${e.lastName}`]))
  const caseMap = Object.fromEntries((cases ?? []).map(c => [c._id, `${c.caseNumber} — ${c.deceasedName}`]))

  return (
    <PageShell
      title="Timesheets"
      actions={<button className="btn-primary flex items-center gap-2" onClick={() => setShowNew(true)}><Plus size={16} />Log Time</button>}
    >
      <div className="card overflow-hidden">
        {!timesheets || timesheets.length === 0 ? (
          <EmptyState icon={Clock} title="No time entries yet" description="Log staff time against cases and schedules." action={<button className="btn-primary" onClick={() => setShowNew(true)}>Log Time</button>} />
        ) : (
          <table className="w-full text-sm">
            <thead className="table-header">
              <tr>
                {['Date', 'Staff Member', 'Case', 'Start', 'End', 'Hours', 'Status', 'Notes'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-struta-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...(timesheets ?? [])].sort((a, b) => b.date.localeCompare(a.date)).map(ts => (
                <tr key={ts._id} className="table-row">
                  <td className="px-4 py-3 font-medium text-struta-800">{ts.date}</td>
                  <td className="px-4 py-3">{empMap[ts.employeeId] ?? '—'}</td>
                  <td className="px-4 py-3 text-struta-500">{ts.caseId ? caseMap[ts.caseId] ?? '—' : '—'}</td>
                  <td className="px-4 py-3">{ts.startTime}</td>
                  <td className="px-4 py-3">{ts.endTime ?? '—'}</td>
                  <td className="px-4 py-3">{ts.hours != null ? `${ts.hours}h` : '—'}</td>
                  <td className="px-4 py-3"><StatusBadge status={ts.status} /></td>
                  <td className="px-4 py-3 text-struta-500 max-w-xs truncate">{ts.description ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Modal open={showNew} onClose={() => setShowNew(false)} title="Log Time Entry"
        footer={<><button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="btn-primary" onClick={handleSave} disabled={saving}>{saving ? 'Saving…' : 'Save Entry'}</button></>}
      >
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group col-span-2">
            <label className="label">Staff Member <span className="text-red-500">*</span></label>
            <select className="select" value={form.employeeId} onChange={set('employeeId')}>
              <option value="">Select employee…</option>
              {(employees ?? []).map(e => <option key={e._id} value={e._id}>{e.firstName} {e.lastName}</option>)}
            </select>
          </div>
          <div className="form-group col-span-2">
            <label className="label">Funeral Case (optional)</label>
            <select className="select" value={form.caseId} onChange={set('caseId')}>
              <option value="">Not linked to a case</option>
              {(cases ?? []).map(c => <option key={c._id} value={c._id}>{c.caseNumber} — {c.deceasedName}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="label">Date <span className="text-red-500">*</span></label>
            <input className="input" type="date" value={form.date} onChange={set('date')} />
          </div>
          <div className="form-group">
            <label className="label">Hours Worked</label>
            <input className="input" type="number" step="0.5" min="0" max="24" value={form.hours} onChange={set('hours')} placeholder="8.0" />
          </div>
          <div className="form-group">
            <label className="label">Start Time</label>
            <input className="input" type="time" value={form.startTime} onChange={set('startTime')} />
          </div>
          <div className="form-group">
            <label className="label">End Time</label>
            <input className="input" type="time" value={form.endTime} onChange={set('endTime')} />
          </div>
          <div className="form-group col-span-2">
            <label className="label">Description</label>
            <textarea className="input resize-none" rows={3} value={form.description} onChange={set('description')} placeholder="What work was done?" />
          </div>
        </div>
      </Modal>
    </PageShell>
  )
}
