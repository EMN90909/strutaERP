import { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { StatusBadge, Modal } from '../../components/ui/LoadingScreen'
import { ArrowLeft, Plus, CheckCircle, Clock, Circle } from 'lucide-react'
import { format } from 'date-fns'

const STATUSES = ['lead', 'consultation', 'quoted', 'booked', 'in_progress', 'completed', 'cancelled'] as const

export default function CaseDetail() {
  const { id } = useParams<{ id: string }>()
  const { tenantId } = useTenant()
  const c = useQuery(api.cases.getCase, { tenantId, caseId: id as any })
  const tasks = useQuery(api.cases.getCaseTasks, { tenantId, caseId: id as any })
  const employees = useQuery(api.data.listEmployees, { tenantId })
  const updateCase = useMutation(api.cases.updateCase)
  const addTask = useMutation(api.cases.addCaseTask)
  const updateTask = useMutation(api.cases.updateCaseTask)

  const [showTask, setShowTask] = useState(false)
  const [taskForm, setTaskForm] = useState({ title: '', description: '', dueDate: '', priority: 'normal' as const, assignedToId: '' })
  const [saving, setSaving] = useState(false)

  if (!c) return <div className="p-6 text-struta-400">Loading case…</div>

  async function handleStatusChange(status: typeof STATUSES[number]) {
    await updateCase({ tenantId, caseId: id as any, status })
  }

  async function handleAddTask() {
    if (!taskForm.title) return
    setSaving(true)
    try {
      await addTask({
        tenantId, caseId: id as any,
        title: taskForm.title,
        description: taskForm.description || undefined,
        dueDate: taskForm.dueDate || undefined,
        priority: taskForm.priority,
        assignedToId: taskForm.assignedToId ? taskForm.assignedToId as any : undefined,
      })
      setShowTask(false)
      setTaskForm({ title: '', description: '', dueDate: '', priority: 'normal', assignedToId: '' })
    } finally { setSaving(false) }
  }

  async function toggleTask(taskId: string, done: boolean) {
    await updateTask({ tenantId, taskId: taskId as any, status: done ? 'done' : 'pending' })
  }

  const taskIcon = (status: string) => {
    if (status === 'done') return <CheckCircle size={16} className="text-green-500" />
    if (status === 'in_progress') return <Clock size={16} className="text-yellow-500" />
    return <Circle size={16} className="text-struta-300" />
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="page-header">
        <div className="flex items-center gap-3">
          <Link to="/cases" className="text-struta-400 hover:text-struta-700"><ArrowLeft size={18} /></Link>
          <div>
            <h1 className="page-title">{c.deceasedName}</h1>
            <p className="text-xs text-struta-500">{c.caseNumber}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <select
            className="select text-sm w-auto"
            value={c.status}
            onChange={e => handleStatusChange(e.target.value as any)}
          >
            {STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
          </select>
          <StatusBadge status={c.status} />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Details */}
          <div className="lg:col-span-2 flex flex-col gap-5">
            {/* Case Info */}
            <div className="card">
              <h2 className="text-sm font-sans font-semibold text-struta-800 mb-4">Case Details</h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                {[
                  ['Date of Death', c.deceasedDod ? format(new Date(c.deceasedDod), 'd MMM yyyy') : '—'],
                  ['Service Date',  c.serviceDate ? format(new Date(c.serviceDate), 'd MMM yyyy') : '—'],
                  ['Service Type',  c.serviceType ?? '—'],
                  ['Location',      c.serviceLocation ?? '—'],
                  ['Case Value',    c.totalValue ? `KES ${c.totalValue.toLocaleString()}` : '—'],
                  ['Created',       format(new Date(c.createdAt), 'd MMM yyyy')],
                ].map(([label, value]) => (
                  <div key={label}>
                    <p className="text-xs text-struta-400 mb-0.5">{label}</p>
                    <p className="font-medium text-struta-900">{value}</p>
                  </div>
                ))}
              </div>
              {c.notes && (
                <div className="mt-4 pt-4 border-t border-struta-100">
                  <p className="text-xs text-struta-400 mb-1">Notes</p>
                  <p className="text-sm text-struta-700">{c.notes}</p>
                </div>
              )}
            </div>

            {/* Tasks */}
            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-sans font-semibold text-struta-800">Tasks</h2>
                <button className="btn-ghost text-xs gap-1" onClick={() => setShowTask(true)}><Plus size={13} /> Add Task</button>
              </div>
              {!tasks?.length ? (
                <p className="text-sm text-struta-400 text-center py-4">No tasks yet.</p>
              ) : (
                <div className="divide-y divide-struta-100">
                  {tasks.map(t => (
                    <div key={t._id} className="flex items-start gap-3 py-3">
                      <button onClick={() => toggleTask(t._id, t.status !== 'done')} className="mt-0.5 flex-shrink-0">
                        {taskIcon(t.status)}
                      </button>
                      <div className="flex-1">
                        <p className={`text-sm font-medium ${t.status === 'done' ? 'line-through text-struta-400' : 'text-struta-900'}`}>{t.title}</p>
                        {t.dueDate && <p className="text-xs text-struta-400 mt-0.5">Due {format(new Date(t.dueDate), 'd MMM yyyy')}</p>}
                      </div>
                      <span className={`badge text-xs ${t.priority === 'high' ? 'badge-red' : t.priority === 'normal' ? 'badge-blue' : 'badge-gray'}`}>{t.priority}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="flex flex-col gap-4">
            <div className="card">
              <h2 className="text-sm font-sans font-semibold text-struta-800 mb-3">Pipeline Stage</h2>
              <div className="flex flex-col gap-1">
                {STATUSES.map(s => (
                  <button
                    key={s}
                    onClick={() => handleStatusChange(s)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all text-left ${c.status === s ? 'bg-struta-600 text-white' : 'text-struta-600 hover:bg-struta-100'}`}
                  >
                    <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${c.status === s ? 'bg-white' : 'bg-struta-300'}`} />
                    {s.replace(/_/g, ' ')}
                  </button>
                ))}
              </div>
            </div>
            <div className="card">
              <h2 className="text-sm font-sans font-semibold text-struta-800 mb-3">Quick Links</h2>
              <div className="flex flex-col gap-2">
                <Link to="/invoices" className="text-xs text-struta-600 hover:underline">→ Create invoice for this case</Link>
                <Link to="/timesheets" className="text-xs text-struta-600 hover:underline">→ Log staff time</Link>
                <Link to="/messages" className="text-xs text-struta-600 hover:underline">→ Send message to team</Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Task Modal */}
      <Modal open={showTask} onClose={() => setShowTask(false)} title="Add Task"
        footer={
          <>
            <button className="btn-secondary" onClick={() => setShowTask(false)}>Cancel</button>
            <button className="btn-primary" onClick={handleAddTask} disabled={saving || !taskForm.title}>
              {saving ? 'Saving…' : 'Add Task'}
            </button>
          </>
        }
      >
        <div className="form-group">
          <label className="label">Task Title *</label>
          <input className="input" value={taskForm.title} onChange={e => setTaskForm(f => ({ ...f, title: e.target.value }))} placeholder="e.g. Arrange transport" />
        </div>
        <div className="form-group">
          <label className="label">Description</label>
          <textarea className="input" rows={2} value={taskForm.description} onChange={e => setTaskForm(f => ({ ...f, description: e.target.value }))} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group">
            <label className="label">Due Date</label>
            <input type="date" className="input" value={taskForm.dueDate} onChange={e => setTaskForm(f => ({ ...f, dueDate: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="label">Priority</label>
            <select className="select" value={taskForm.priority} onChange={e => setTaskForm(f => ({ ...f, priority: e.target.value as any }))}>
              <option value="low">Low</option>
              <option value="normal">Normal</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>
        <div className="form-group">
          <label className="label">Assign to</label>
          <select className="select" value={taskForm.assignedToId} onChange={e => setTaskForm(f => ({ ...f, assignedToId: e.target.value }))}>
            <option value="">Unassigned</option>
            {(employees ?? []).map(e => <option key={e._id} value={e._id}>{e.firstName} {e.lastName}</option>)}
          </select>
        </div>
      </Modal>
    </div>
  )
}
