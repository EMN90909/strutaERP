import { useState } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '../../../convex/_generated/api'
import { useTenant } from '../../contexts/TenantContext'
import { PageShell, StatusBadge, EmptyState, Modal, SearchInput } from '../../components/ui/LoadingScreen'
import { Briefcase, Plus } from 'lucide-react'
import { Link } from 'react-router-dom'
import { format } from 'date-fns'

const STATUSES = ['', 'lead', 'consultation', 'quoted', 'booked', 'in_progress', 'completed', 'cancelled']

export default function CasesPage() {
  const { tenantId } = useTenant()
  const cases = useQuery(api.cases.listCases, { tenantId })
  const contacts = useQuery(api.data.listContacts, { tenantId })
  const createCase = useMutation(api.cases.createCase)

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [form, setForm] = useState({
    deceasedName: '', deceasedDod: '', serviceDate: '', serviceType: '',
    serviceLocation: '', notes: '', primaryContactId: '',
  })
  const [saving, setSaving] = useState(false)

  const filtered = (cases ?? []).filter(c => {
    const matchSearch = !search || c.deceasedName.toLowerCase().includes(search.toLowerCase()) || c.caseNumber.toLowerCase().includes(search.toLowerCase())
    const matchStatus = !statusFilter || c.status === statusFilter
    return matchSearch && matchStatus
  })

  async function handleCreate() {
    if (!form.deceasedName) return
    setSaving(true)
    try {
      await createCase({
        tenantId,
        deceasedName: form.deceasedName,
        deceasedDod: form.deceasedDod || undefined,
        serviceDate: form.serviceDate || undefined,
        serviceType: form.serviceType || undefined,
        serviceLocation: form.serviceLocation || undefined,
        notes: form.notes || undefined,
        primaryContactId: form.primaryContactId ? form.primaryContactId as any : undefined,
      })
      setShowNew(false)
      setForm({ deceasedName: '', deceasedDod: '', serviceDate: '', serviceType: '', serviceLocation: '', notes: '', primaryContactId: '' })
    } finally { setSaving(false) }
  }

  return (
    <PageShell
      title="Cases"
      actions={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> New Case</button>}
    >
      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <SearchInput value={search} onChange={setSearch} placeholder="Search cases…" />
        <select className="select w-auto" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          {STATUSES.map(s => <option key={s} value={s}>{s ? s.replace(/_/g, ' ') : 'All statuses'}</option>)}
        </select>
      </div>

      {/* Table */}
      {!cases ? (
        <p className="text-sm text-struta-400">Loading…</p>
      ) : filtered.length === 0 ? (
        <EmptyState icon={Briefcase} title="No cases found" description="Create your first funeral case to get started." action={<button className="btn-primary" onClick={() => setShowNew(true)}><Plus size={15} /> New Case</button>} />
      ) : (
        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr>
                <th>Case No.</th>
                <th>Deceased</th>
                <th>Service Date</th>
                <th>Service Type</th>
                <th>Status</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c._id}>
                  <td><Link to={`/cases/${c._id}`} className="text-struta-600 font-medium hover:underline">{c.caseNumber}</Link></td>
                  <td className="font-medium text-struta-900">{c.deceasedName}</td>
                  <td>{c.serviceDate ? format(new Date(c.serviceDate), 'd MMM yyyy') : <span className="text-struta-400">—</span>}</td>
                  <td>{c.serviceType ?? <span className="text-struta-400">—</span>}</td>
                  <td><StatusBadge status={c.status} /></td>
                  <td className="text-struta-400">{format(new Date(c.createdAt), 'd MMM yyyy')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* New Case Modal */}
      <Modal open={showNew} onClose={() => setShowNew(false)} title="New Funeral Case"
        footer={
          <>
            <button className="btn-secondary" onClick={() => setShowNew(false)}>Cancel</button>
            <button className="btn-primary" onClick={handleCreate} disabled={saving || !form.deceasedName}>
              {saving ? 'Creating…' : 'Create Case'}
            </button>
          </>
        }
      >
        <div className="form-group">
          <label className="label">Deceased Name *</label>
          <input className="input" value={form.deceasedName} onChange={e => setForm(f => ({ ...f, deceasedName: e.target.value }))} placeholder="Full name of deceased" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="form-group">
            <label className="label">Date of Death</label>
            <input type="date" className="input" value={form.deceasedDod} onChange={e => setForm(f => ({ ...f, deceasedDod: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="label">Service Date</label>
            <input type="date" className="input" value={form.serviceDate} onChange={e => setForm(f => ({ ...f, serviceDate: e.target.value }))} />
          </div>
        </div>
        <div className="form-group">
          <label className="label">Service Type</label>
          <select className="select" value={form.serviceType} onChange={e => setForm(f => ({ ...f, serviceType: e.target.value }))}>
            <option value="">Select type…</option>
            {['Burial', 'Cremation', 'Memorial Service', 'Graveside Service', 'Repatriation', 'Other'].map(t => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="label">Service Location</label>
          <input className="input" value={form.serviceLocation} onChange={e => setForm(f => ({ ...f, serviceLocation: e.target.value }))} placeholder="Church, cemetery, etc." />
        </div>
        <div className="form-group">
          <label className="label">Primary Contact / Family</label>
          <select className="select" value={form.primaryContactId} onChange={e => setForm(f => ({ ...f, primaryContactId: e.target.value }))}>
            <option value="">Select contact…</option>
            {(contacts ?? []).filter(c => c.type === 'family').map(c => (
              <option key={c._id} value={c._id}>{c.firstName} {c.lastName}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label className="label">Notes</label>
          <textarea className="input" rows={3} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Any additional notes…" />
        </div>
      </Modal>
    </PageShell>
  )
}
